<h2>User Profile</h2>

<a href="<?php echo e(route('dashboard')); ?>">Dashboard</a> | <a href="<?php echo e(route('profile')); ?>">Profile</a> | <a href="<?php echo e(route('logout')); ?>">Logout</a>

<hr>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
    <?php echo e(session('success')); ?>

<?php endif; ?>

<?php if(session('error')): ?>
    <?php echo e(session('error')); ?>

<?php endif; ?>


<form action="<?php echo e(route('profile_update')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <table>
        <tr>
            <td>Name: </td>
            <td><input type="text" name="name" value="<?php echo e(Auth::guard('web')->user()->name); ?>"></td>
        </tr>
        <tr>
            <td>Email: </td>
            <td><input type="text" name="email" value="<?php echo e(Auth::guard('web')->user()->email); ?>"></td>
        </tr>
        <tr>
            <td>Password: </td>
            <td><input type="password" name="password"></td>
        </tr>
        <tr>
            <td>Confirm Password: </td>
            <td><input type="password" name="confirm_password"></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <button type="submit">Update Profile</button>
            </td>
        </tr>
    </table>
</form>
<?php /**PATH /Applications/MAMP/htdocs/multi_auth/resources/views/user/profile.blade.php ENDPATH**/ ?>