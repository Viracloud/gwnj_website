<h2>Admin Dashboard</h2>

<a href="<?php echo e(route('admin_dashboard')); ?>">Dashboard</a> | <a href="<?php echo e(route('admin_profile')); ?>">Profile</a> | <a href="<?php echo e(route('admin_logout')); ?>">Logout</a>

<hr>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
    <?php echo e(session('success')); ?>

<?php endif; ?>

<?php if(session('error')): ?>
    <?php echo e(session('error')); ?>

<?php endif; ?>


<form action="<?php echo e(route('admin_profile_update')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <table>
        <tr>
            <td>Existing Photo: </td>
            <td>
                <?php if(Auth::guard('admin')->user()->photo): ?>
                    <img src="<?php echo e(asset('uploads/'.Auth::guard('admin')->user()->photo)); ?>" style="width:100px;">
                <?php else: ?>
                    No Photo Found!
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td>Change Photo: </td>
            <td>
                <input type="file" name="photo">
            </td>
        </tr>
        <tr>
            <td>Name: </td>
            <td><input type="text" name="name" value="<?php echo e(Auth::guard('admin')->user()->name); ?>"></td>
        </tr>
        <tr>
            <td>Email: </td>
            <td><input type="text" name="email" value="<?php echo e(Auth::guard('admin')->user()->email); ?>"></td>
        </tr>
        <tr>
            <td>Password: </td>
            <td><input type="password" name="password"></td>
        </tr>
        <tr>
            <td>Confirm Password: </td>
            <td><input type="password" name="confirm_password"></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <button type="submit">Update Profile</button>
            </td>
        </tr>
    </table>
</form>
<?php /**PATH /Applications/MAMP/htdocs/multi_auth/resources/views/admin/profile.blade.php ENDPATH**/ ?>