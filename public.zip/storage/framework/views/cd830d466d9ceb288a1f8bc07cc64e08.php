<a href="<?php echo e(route('home')); ?>">Home</a> | <a href="<?php echo e(route('about')); ?>">About</a> | <a href="<?php echo e(route('login')); ?>">Login</a> | <a href="<?php echo e(route('register')); ?>">Register</a>

<h1>Home Page</h1><?php /**PATH /Applications/MAMP/htdocs/admin_panel_laravel/resources/views/front/home.blade.php ENDPATH**/ ?>