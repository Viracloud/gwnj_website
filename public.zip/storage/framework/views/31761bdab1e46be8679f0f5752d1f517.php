<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1>Settings - Theme Color</h1>
</div>

<form action="<?php echo e(route('admin_setting_theme_color_update')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row g-4">
        <div class="col-12 col-xl-12">
            <div class="card-custom-p mb-4">
                <div class="mb-3">
                    <label class="label-custom">Theme Color</label>
                    <input type="text" name="theme_color" value="<?php echo e($setting->theme_color); ?>" class="form-control-custom jscolor">
                </div>
            </div>
            <div class="card-custom-p mb-4">
                <div>
                    <button type="submit" class="btn-admin-primary">Update</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/setting/theme_color.blade.php ENDPATH**/ ?>