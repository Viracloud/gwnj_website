<?php $__env->startSection('banner'); ?>
<section class="tmp-breadcrumb-area bg-image banner-bg" style="background-image: url(<?php echo e(asset('uploads/'.$global_setting->banner)); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content-main text-center">
                    <h1 class="title text-white fw-bold display-4 mb-3"><?php echo e($service->title); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb justify-content-center align-items-center mb-0">
                            <li class="breadcrumb-item"><i class="fa-solid fa-house text-primary-orange"></i>
                                <a href="<?php echo e(route('home')); ?>" class="text-white text-decoration-none opacity-75">Home</a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('services')); ?>" class="text-white text-decoration-none opacity-75"><?php echo e($page_data->page_title); ?></a>
                            </li>
                            <li class="breadcrumb-item active text-white fw-bold" aria-current="page">
                                <?php echo e($service->title); ?>

                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape">
        <img src="<?php echo e(asset('uploads/shape-01.png')); ?>" class="shape-1" alt="">
        <img src="<?php echo e(asset('uploads/shape-02.png')); ?>" class="shape-2" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="service-details-section service-section-gap">
    <div class="container">
        <div class="row g-5">
            <!-- Sidebar Area -->
            <div class="col-lg-4 order-2 order-lg-1">
                <div class="left-sidebar">

                    <!-- Widget: Service List -->
                    <div class="single-wrapper service-list mb-4">
                        <h2 class="title-main">All Services</h2>
                        <ul class="list-unstyled p-0 m-0">
                            <?php $__currentLoopData = $all_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('service', $item->slug)); ?>" class="<?php echo e($service->id == $item->id ? 'active' : ''); ?>"><?php echo e($item->title); ?> <span><i class="fa-solid fa-arrow-right"></i></span></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <!-- Widget: Emergency Contact -->
                    <?php if($service->phone_text != '' || $service->phone_number != ''): ?>
                    <div class="single-wrapper contact-area mb-4 p-4">
                        <div class="d-flex align-items-center gap-3">
                            <div class="icon-box">
                                <i class="fa-solid fa-phone"></i>
                            </div>
                            <div class="text">
                                <?php if($service->phone_text != ''): ?>
                                <p class="mb-0 text-muted small fw-bold"><?php echo e($service->phone_text); ?></p>
                                <?php endif; ?>
                                <?php if($service->phone_number != ''): ?>
                                <a href="tel:<?php echo e($service->phone_number); ?>" class="phone h5 fw-bold text-dark text-decoration-none"><?php echo e($service->phone_number); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Widget: Quick Contact Form -->
                    <div class="single-wrapper contact-area p-4 mb-4">
                        <div class="content-quick-contact-service">
                            <h2 class="title h5 fw-bold mb-4">Get a free consultation?</h2>
                            <form action="<?php echo e(route('service_contact')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="service_title" value="<?php echo e($service->title); ?>">
                                <div class="single-quick-action mb-3">
                                    <i class="fa-regular fa-face-smile"></i>
                                    <input type="text" class="form-control" placeholder="Your Name *" name="name" required>
                                </div>
                                <div class="single-quick-action mb-3">
                                    <i class="fa-regular fa-envelope"></i>
                                    <input type="email" class="form-control" placeholder="Your Email *" name="email" required>
                                </div>
                                <div class="single-quick-action mb-4">
                                    <i class="fa-regular fa-message"></i>
                                    <textarea class="form-control" placeholder="Your Message *" name="message" rows="3" required></textarea>
                                </div>
                                <button type="submit" class="tmp-btn btn-primary w-100 hover-icon-reverse">
                                    <span class="icon-reverse-wrapper">
                                        <span class="btn-text">Send Message</span>
                                        <span class="btn-icon"><i class="fa-solid fa-arrow-right"></i></span>
                                    </span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content Area -->
            <div class="col-lg-8 order-1 order-lg-2">
                <div class="right-content-area checkout-padding-shadow p-0">
                    <div class="image-section" style="background-image: url(<?php echo e(asset('uploads/'.$service->image)); ?>)"></div>

                    <div class="p-4 p-md-5 pt-0">
                        <div class="description mb-4">
                            <?php echo $service->description; ?>

                        </div>

                        <!-- Accordion Area -->
                        <?php if(count($all_faqs) > 0): ?>
                        <div class="faq-content-area mt-4">
                            <div class="accordion" id="accordionExample">

                                <h3 class="fw-700">Service FAQs</h3>

                                <?php $__currentLoopData = $all_faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item mb-3 border rounded-3 overflow-hidden">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button <?php echo e($loop->first ? '' : 'collapsed'); ?> fw-bold py-3" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($loop->iteration); ?>">
                                            <i class="fa-solid fa-hard-hat me-3 text-primary"></i> <?php echo e($item->question); ?>

                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo e($loop->iteration); ?>" class="accordion-collapse collapse <?php echo e($loop->first ? 'show' : ''); ?>"
                                        data-bs-parent="#accordionExample">
                                        <div class="accordion-body bg-light">
                                            <div class="desc mb-4">
                                                <?php echo nl2br($item->answer); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <?php endif; ?>

                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/service.blade.php ENDPATH**/ ?>