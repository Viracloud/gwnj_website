<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1>Settings - Layout Direction</h1>
</div>

<form action="<?php echo e(route('admin_setting_layout_direction_update')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row g-4">
        <div class="col-12 col-xl-12">
            <div class="card-custom-p mb-4">
                <div class="row">
                    <div class="col-lg-4 mb-3">
                        <label class="label-custom">Layout Direction</label>
                        <select name="layout_direction" class="form-control-custom">
                            <option value="ltr" <?php echo e($setting->layout_direction == 'ltr' ? 'selected' : ''); ?>>LTR</option>
                            <option value="rtl" <?php echo e($setting->layout_direction == 'rtl' ? 'selected' : ''); ?>>RTL</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="card-custom-p mb-4">
                <div>
                    <button type="submit" class="btn-admin-primary">Update</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/setting/layout_direction.blade.php ENDPATH**/ ?>