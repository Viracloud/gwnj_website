<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/dataTables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/flatpickr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/iziToast.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/style.css')); ?>">
<!-- <link rel="stylesheet" href="dist-admin/css/rtl.css"> --><?php /**PATH /Applications/MAMP/htdocs/admin_panel_laravel/resources/views/admin/layouts/styles.blade.php ENDPATH**/ ?>