<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/dataTables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/flatpickr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/iziToast.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/style.css')); ?>">
<?php if($global_setting->layout_direction == 'rtl'): ?>
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/rtl.css')); ?>">
<?php endif; ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/layouts/styles.blade.php ENDPATH**/ ?>