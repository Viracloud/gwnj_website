<script src="<?php echo e(asset('dist-admin/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-admin/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-admin/js/chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-admin/js/dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-admin/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-admin/js/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-admin/vendor/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-admin/js/jscolor.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-admin/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist-admin/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('dist-admin/js/custom.js')); ?>"></script>

<?php if($errors->any()): ?>
    <script>
        iziToast.error({
            message: '<?php echo e($errors->first()); ?>',
            position: 'topRight'
        });
    </script>
<?php endif; ?>

<?php if(session('success')): ?>
    <script>
        iziToast.success({
            message: '<?php echo e(session('success')); ?>',
            position: 'topRight'
        });
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <script>
        iziToast.error({
            message: '<?php echo e(session('error')); ?>',
            position: 'topRight'
        });
    </script>
<?php endif; ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/layouts/scripts.blade.php ENDPATH**/ ?>