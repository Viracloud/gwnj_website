<?php $__env->startSection('banner'); ?>
<section class="tmp-breadcrumb-area bg-image banner-bg" style="background-image: url(<?php echo e(asset('uploads/'.$global_setting->banner)); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content-main text-center">
                    <h1 class="title text-white fw-bold display-4 mb-3"><?php echo e($page_data->cart_page_title); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb justify-content-center align-items-center mb-0">
                            <li class="breadcrumb-item"><i class="fa-solid fa-house text-primary-orange"></i>
                                <a href="<?php echo e(route('home')); ?>" class="text-white text-decoration-none opacity-75">Home</a>
                            </li>
                            <li class="breadcrumb-item active text-white fw-bold" aria-current="page">
                                <?php echo e($page_data->cart_page_title); ?>

                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape">
        <img src="<?php echo e(asset('uploads/shape-01.png')); ?>" class="shape-1" alt="">
        <img src="<?php echo e(asset('uploads/shape-02.png')); ?>" class="shape-2" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="cart-view-section py-24 pt-5">
    <div class="container py-5">

        <div class="row">
            <div class="col-lg-8">
                <div class="cart-card p-4">
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead>
                                <tr class="text-center">
                                    <th class="text-start">Products</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>SubTotal</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $main_subtotal = 0;
                                ?>
                                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $product_detail = \App\Models\Product::where('id',$item['product_id'])->first();
                                ?>
                                <form action="<?php echo e(route('update_cart')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($item['product_id']); ?>">
                                <tr class="text-center">
                                    <td class="text-start d-flex align-items-center">
                                        <img src="<?php echo e(asset('uploads/'.$product_detail->image)); ?>" class="product-img me-3" alt="<?php echo e($item['name']); ?>">
                                        <div>
                                            <div class="fw-bold">
                                                <a href="<?php echo e(route('product',$product_detail->slug)); ?>" style="text-decoration:none;color:#333333;">
                                                    <?php echo e($item['name']); ?>

                                                </a>
                                            </div>
                                        </div>
                                    </td>
                                    <td>$<?php echo e($product_detail->price); ?></td>
                                    <td class="w-50px">
                                        <div class="d-flex justify-content-center">
                                            <input type="number" class="form-control qty-input" name="quantity" value="<?php echo e($item['quantity']); ?>" min="0">
                                        </div>
                                    </td>
                                    <?php
                                    $subtotal = $item['quantity'] * $product_detail->price;
                                    ?>
                                    <td class="fw-bold text-dark">$<?php echo e(number_format($subtotal, 2)); ?></td>
                                    <td>
                                        <button type="submit" style="text-decoration: none; color: inherit;">
                                            <i class="fa-solid fa-edit fs-5"></i>
                                        </button>
                                        <a href="<?php echo e(route('remove_from_cart', ['product_id' => $item['product_id']])); ?>" onClick="return confirm('Are you sure?')">
                                            <i class="fa-solid fa-circle-xmark remove-item fs-5"></i>
                                        </a>
                                    </td>
                                </tr>
                                </form>
                                <?php
                                $main_subtotal += $subtotal;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex coupon-section justify-content-between mt-4">
                        <form action="<?php echo e(route('apply_coupon')); ?>" method="post" class="d-flex gap-2">
                            <?php echo csrf_field(); ?>
                            <input type="text" class="form-control bg-light-gray" placeholder="Coupon Code" name="code">
                            <button type="submit" class="primary-btns hover-icon-reverse">
                                <span class="btn-text-content">
                                    <span class="btn-icon-wrapper">
                                        <span class="btn-text pe-50">Apply Coupon</span>
                                    </span>
                                </span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card summary-card p-4">
                    <h5 class="fw-bold mb-4">Cart Totals</h5>

                    <?php
                    $final_amount = $main_subtotal;
                    ?>
                    
                    <div class="d-flex justify-content-between mb-3">
                        <span>Subtotal</span>
                        <span class="fw-bold">$<?php echo e(number_format($main_subtotal, 2)); ?></span>
                    </div>

                    <div class="d-flex justify-content-between mb-3">
                        <span>Discount</span>
                        <span class="fw-bold">
                            <?php if(session()->has('coupon')): ?>
                            <?php
                            $discount_amount = $main_subtotal * (session('coupon')['percentage'] / 100);
                            $final_amount = $final_amount - $discount_amount;
                            ?>
                            - $<?php echo e(number_format($discount_amount, 2)); ?>

                            <?php else: ?>
                            - $0.00
                            <?php endif; ?>
                        </span>
                    </div>

                    <?php if(session()->has('coupon')): ?>
                    <div style="color:rgb(37, 145, 68);">
                        Applied Coupon: <?php echo e(session('coupon')['code']); ?><br>
                        <a href="<?php echo e(route('remove_coupon')); ?>" style="color:red;">Remove</a>
                    </div>
                    <?php endif; ?>

                    <hr>
                    <form id="shippingForm" action="<?php echo e(route('update_shipping')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span style="width:30%;">Shipping</span>
                            <div style="width:70%;">
                                <?php $__currentLoopData = $shipping_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    
                                    <input class="form-check-input shipping-radio" 
                                        type="radio" 
                                        name="shipping_id" 
                                        value="<?php echo e($shipping_method->id); ?>"
                                        id="ship_<?php echo e($shipping_method->id); ?>"
                                        <?php echo e((session('shipping_method')['id'] ?? null) == $shipping_method->id ? 'checked' : ''); ?>>
                                    
                                    <label class="form-check-label" for="ship_<?php echo e($shipping_method->id); ?>">
                                        <b><?php echo e($shipping_method->name); ?> - $<?php echo e(number_format($shipping_method->cost, 2)); ?></b><br>
                                        <small>(<?php echo e($shipping_method->estimated_days); ?>)</small>
                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    </form>
                    <script>
                        // Pure JavaScript to submit the form on change
                        document.querySelectorAll('.shipping-radio').forEach(radio => {
                            radio.addEventListener('change', function() {
                                this.form.submit();
                            });
                        });
                    </script>
                    <hr>
                    <div class="d-flex justify-content-between mb-3">
                        <span>Shipping Cost</span>
                        <span class="fw-bold">
                            <?php
                            $shipping_cost = session('shipping_method')['cost'] ?? 0;
                            $final_amount = $final_amount + $shipping_cost;
                            ?>
                            + $<?php echo e(number_format($shipping_cost, 2)); ?>

                        </span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between mb-4 fs-5 fw-bold">
                        <span>Total</span>
                        <span>$<?php echo e(number_format($final_amount, 2)); ?></span>
                    </div>
                    <a href="<?php echo e(route('checkout')); ?>" class="primary-btns hover-icon-reverse">
                        <span class="btn-text-content">
                            <span class="btn-icon-wrapper d-flex justify-content-center">
                                <span class="btn-text">Proceed To Checkout </span>
                            </span>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/cart.blade.php ENDPATH**/ ?>