<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1>Settings - Favicon</h1>
</div>

<form action="<?php echo e(route('admin_setting_favicon_update')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row g-4">
        <div class="col-12 col-xl-12">

            <h6 class="cus-heading">Favicon</h6>
            <div class="card-custom-p mb-4">
                <div class="mb-3">
                    <label class="label-custom">Existing Favicon</label>
                    <div>
                        <?php if($setting->favicon): ?>
                            <img src="<?php echo e(asset('uploads/'.$setting->favicon)); ?>" alt="Favicon" style="max-height:50px;">
                        <?php else: ?>
                            <span class="text-muted">No favicon uploaded</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="label-custom">Upload New Favicon</label>
                    <input type="file" name="favicon" class="form-control-custom">
                </div>
            </div>

            <div class="card-custom-p mb-4">
                <div>
                    <button type="submit" class="btn-admin-primary">Update</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/setting/favicon.blade.php ENDPATH**/ ?>