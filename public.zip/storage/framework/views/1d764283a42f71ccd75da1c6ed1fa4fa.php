<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1>Page User Item</h1>
</div>

<form action="<?php echo e(route('admin_page_user_update')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row g-4">
        <div class="col-12 col-xl-12">

            <h6 class="cus-heading">Page Section</h6>
            <div class="card-custom-p mb-4">
                <div class="mb-3">
                    <label class="label-custom">Dashboard Page Title</label>
                    <input type="text" name="dashboard_page_title" value="<?php echo e($page_data->dashboard_page_title); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Profile Page Title</label>
                    <input type="text" name="profile_page_title" value="<?php echo e($page_data->profile_page_title); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Orders Page Title</label>
                    <input type="text" name="orders_page_title" value="<?php echo e($page_data->orders_page_title); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Invoice Page Title</label>
                    <input type="text" name="invoice_page_title" value="<?php echo e($page_data->invoice_page_title); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Reviews Page Title</label>
                    <input type="text" name="reviews_page_title" value="<?php echo e($page_data->reviews_page_title); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Wishlist Page Title</label>
                    <input type="text" name="wishlist_page_title" value="<?php echo e($page_data->wishlist_page_title); ?>" class="form-control-custom">
                </div>
            </div>

            <h6 class="cus-heading">SEO Section</h6>
            <div class="card-custom-p mb-4">
                <div class="mb-3">
                    <label class="label-custom">Title</label>
                    <input type="text" name="seo_title" value="<?php echo e($page_data->seo_title); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Meta Description</label>
                    <textarea name="seo_meta_description" class="form-control-custom"><?php echo e($page_data->seo_meta_description); ?></textarea>
                </div>
            </div>
            
            <div class="card-custom-p mb-4">
                <div>
                    <button type="submit" class="btn-admin-primary">Update</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/page_item/user.blade.php ENDPATH**/ ?>