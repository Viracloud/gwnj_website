<?php $__env->startSection('banner'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="hero-slider-section">
    <div class="hero-slider owl-carousel owl-theme">

        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="hero-slide-item banner-five-main-wrapper bg-style slider-bg-1" style="background-image: url('<?php echo e(asset('uploads/'.$slider->image)); ?>');">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7 text-white">
                        <h1 class="mb-4 hero-slider-title">
                            <?php echo e($slider->heading); ?>

                        </h1>
                        <p class="hero-slide-paragraph">
                            <?php echo nl2br($slider->text); ?>

                        </p>
                        <?php if($slider->button_text != '' && $slider->button_link != ''): ?>
                        <div>
                            <a href="<?php echo e($slider->button_link); ?>" class="primary-btns hover-icon-reverse">
                                <span class="btn-text-content">
                                    <span class="btn-icon-wrapper">
                                        <span class="btn-text"><?php echo e($slider->button_text); ?></span>
                                        <span class="btn-icon-hover"><i class="fa-solid fa-arrow-right"></i></span>
                                    </span>
                                </span>
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</section>


<?php if($page_data->about_status == 'Show'): ?>
<section class="px-3  overflow-hidden">
    <div class="container py-24">
        <div class="row align-items-center g-5">
            <div class="col-md-5">
                <div class="position-relative about-img-wrapper">
                    <img loading="lazy" src="<?php echo e(asset('uploads/shape-01.svg')); ?>" alt="shape" class="position-absolute about-shape1">
                    <img loading="lazy" src="<?php echo e(asset('uploads/'.$about_item->image)); ?>" class="img-fluid rounded-3 position-relative z-1" alt="construction_image">
                    <img loading="lazy" src="<?php echo e(asset('uploads/shape-02.svg')); ?>" alt="shape" class="position-absolute about-shape2">

                    <?php if($about_item->experience_year != '' || $about_item->experience_text != ''): ?>
                    <div class="counter-badge position-absolute bg-white shadow p-4 rounded-3 d-flex align-items-center z-2">
                        <div>
                            <?php if($about_item->experience_year != ''): ?>
                            <h3 class="h2 fw-bold mb-0 text-primary"><?php echo e($about_item->experience_year); ?>+</h3>
                            <?php endif; ?>
                            <?php if($about_item->experience_text != ''): ?>
                            <p class="small text-muted mb-0"><?php echo e($about_item->experience_text); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($about_item->youtube_id != ''): ?>
                    <a href="https://www.youtube.com/watch?v=<?php echo e($about_item->youtube_id); ?>"
                        class="glightbox video-play-btn about-play-btns  mb-4 me-4 z-30 text-decoration-none">
                        <span class="play-icon shadow-lg">
                            <i class="fa-solid fa-play"></i>
                        </span>
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-7">
                <div class="section-title">
                    <?php if($about_item->subheading != ''): ?>
                    <p class="text-primary fw-bold text-uppercase mb-2">
                        <?php echo e($about_item->subheading); ?>

                    </p>
                    <?php endif; ?>
                    <h2 class="main-title fw-600 mb-4">
                        <?php echo nl2br($about_item->heading); ?>

                    </h2>
                    <div class="description">
                        <?php echo nl2br($about_item->text); ?>

                    </div>
                </div>

                <div class="mt-4">
                    <?php if($about_item->phone_text != '' || $about_item->phone_number != ''): ?>
                    <div class="d-flex align-items-center mb-30">
                        <div class="call-icon bg-light p-3 rounded-circle me-3 border">
                            <i class="fa-solid fa-phone-volume text-primary fs-4"></i>
                        </div>
                        <div>
                            <?php if($about_item->phone_text != ''): ?>
                            <p class="text-muted mb-2"><?php echo e($about_item->phone_text); ?></p>
                            <?php endif; ?>
                            <?php if($about_item->phone_number != ''): ?>
                            <a href="tel:<?php echo e($about_item->phone_number); ?>" class="h6 fw-bold text-decoration-none text-dark"><?php echo e($about_item->phone_number); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($about_item->button_link != '' && $about_item->button_text != ''): ?>
                    <a href="<?php echo e($about_item->button_link); ?>" class="primary-btns hover-icon-reverse">
                        <span class="btn-text-content">
                            <span class="btn-icon-wrapper">
                                <span class="btn-icon"><i class="fa-solid fa-phone"></i></span>
                                <span class="btn-text"><?php echo e($about_item->button_text); ?></span>
                            </span>
                        </span>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>


<?php if($page_data->service_status == 'Show'): ?>
<section class="services-section px-3">
    <div class="container py-24">
        <div class="row align-items-center mb-5">
            <div class="col-lg-6 col-md-7">
                <span class="sub-title"><?php echo e($page_data->service_subheading); ?></span>
                <h2 class="main-title"><?php echo nl2br($page_data->service_heading); ?></h2>
            </div>
            <div class="col-lg-5 offset-lg-1 col-md-5 mt-3 mt-md-0">
                <p class="description mb-0">
                    <?php echo nl2br($page_data->service_text); ?>

                </p>
            </div>
        </div>
        <div class="row g-4">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <div class="service-card p-4 h-100">
                    <div class="card-icon mb-4">
                        <img src="<?php echo e(asset('uploads/'.$service->icon)); ?>" alt="Icon" width="55">
                    </div>
                    <h3 class="card-title"><?php echo e($service->title); ?></h3>
                    <p class="card-text"><?php echo nl2br($service->short_description); ?></p>

                    <a href="<?php echo e(route('service',$service->slug)); ?>" class="read-more-btn">
                        <span class="ms-3">Read More</span>
                        <div class="arrow-circle">
                            <span class="arrow-icon">↗</span>
                        </div>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>


<?php if($page_data->project_status == 'Show'): ?>
<section class="works-process-area px-3">
    <div class="container">
        <div class="row align-items-center mb-5">
            <div class="col-lg-6 col-md-7">
                <span class="sub-title"><?php echo e($page_data->project_subheading); ?></span>
                <h2 class="main-title"><?php echo nl2br($page_data->project_heading); ?></h2>
            </div>
            <div class="col-lg-5 offset-lg-1 col-md-5 mt-3 mt-md-0">
                <p class="description mb-0">
                    <?php echo nl2br($page_data->project_text); ?>

                </p>
            </div>
        </div>

        <div class="row g-4">

            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-xl-4">
                <div class="process-card position-relative overflow-hidden rounded-3 shadow-sm">
                    <div class="card-bg-img worker-bg-1" style="background-image: url('<?php echo e(asset('uploads/'.$project->image)); ?>');"></div>
                    <div class="card-content-normal p-4">
                        <h3 class="title works-title h5 fw-bold">
                            <?php echo e($project->title); ?>

                        </h3>
                    </div>
                    <div class="card-content-hover p-4 d-flex flex-column justify-content-end">
                        <h3 class="title works-title h4 fw-bold mb-3">
                            <?php echo e($project->title); ?>

                        </h3>
                        <div>
                            <a href="<?php echo e(route('project',$project->slug)); ?>" class="primary-btns hover-icon-reverse">
                                <span class="btn-text-content">
                                    <span class="btn-icon-wrapper">
                                        <span class="btn-icon">
                                            <i class="fa-solid fa-arrow-right"></i>
                                        </span>
                                        <span class="btn-text">View Details</span>
                                    </span>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php endif; ?>


<?php if($page_data->testimonial_status == 'Show'): ?>
<section class="testimonial-area py-5 bg-white position-relative">
    <div class="container py-24">
        <div class="row mb-5 text-center">
            <div class="col-12">
                <p class="sub-title"><?php echo e($page_data->testimonial_subheading); ?></p>
                <h2 class="main-title"><?php echo nl2br($page_data->testimonial_heading); ?></h2>
            </div>
        </div>

        <div class="slider-container-relative position-relative px-md-5">
            <div class="owl-carousel owl-theme testimonial-slider-3">

                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item  border shadow-sm px-40">
                    <div class="testimonial-card py-50 m-2 bg-white h-100">
                        <div class="author-info d-flex align-items-center mb-4">
                            <img src="<?php echo e(asset('uploads/'.$testimonial->image)); ?>"
                                class="rounded-circle me-3 border-2 border-white shadow-sm size-60"
                                alt="author">
                            <div>
                                <h4 class="mb-0 fw-bold"><?php echo e($testimonial->name); ?></h4>
                                <p class="text-muted mb-0"><?php echo e($testimonial->designation); ?></p>
                            </div>
                        </div>
                        <p class="testimonial-text text-muted mb-3">
                            <?php echo nl2br($testimonial->comment); ?>

                        </p>
                        <div class="star-rating text-warning small">
                            <i class="fas fa-star"></i><i class="fas fa-star"></i><i
                                class="fas fa-star"></i><i class="fas fa-star"></i><i
                                class="fas fa-star"></i>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</section>
<?php endif; ?>


<?php if($page_data->team_status == 'Show'): ?>
<section class="team-area px-3">
    <div class="container py-24">
        <div class="row mb-5 text-center">
            <div class="col-12">
                <p class="sub-title"><?php echo e($page_data->team_subheading); ?></p>
                <h2 class="main-title"><?php echo nl2br($page_data->team_heading); ?></h2>
            </div>
        </div>

        <div class="row g-4">
            
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-md-4 ">
                <div class="team-card-v2">
                    <div class="image-section">
                        <a href="<?php echo e(route('member', $member->slug)); ?>">
                            <img src="<?php echo e(asset('uploads/'.$member->image)); ?>" class="img-fluid w-100"
                                alt="<?php echo e($member->name); ?>">
                        </a>
                        <div class="social-wrapper">
                            <ul class="list-unstyled mb-0 d-flex justify-content-center gap-2">
                                <?php if($member->facebook != ''): ?>
                                <li>
                                    <a href="<?php echo e($member->facebook); ?>"><i class="fa-brands fa-facebook-f"></i></a>
                                </li>
                                <?php endif; ?>
                                <?php if($member->twitter != ''): ?>
                                <li>
                                    <a href="<?php echo e($member->twitter); ?>"><i class="fa-brands fa-twitter"></i></a>
                                </li>
                                <?php endif; ?>
                                <?php if($member->linkedin != ''): ?>
                                <li>
                                    <a href="<?php echo e($member->linkedin); ?>"><i class="fa-brands fa-linkedin-in"></i></a>
                                </li>
                                <?php endif; ?>
                                <?php if($member->instagram != ''): ?>
                                <li>
                                    <a href="<?php echo e($member->instagram); ?>"><i class="fa-brands fa-instagram"></i></a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="content-area position-relative content-area-padding">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h5 class="title mb-2">
                                    <a href="<?php echo e(route('member', $member->slug)); ?>" class="title text-reset text-decoration-none fw-bold"><?php echo e($member->name); ?></a>
                                </h5>
                                <p class="designation text-muted mb-1"><?php echo e($member->designation); ?></p>
                            </div>
                            <a href="<?php echo e(route('member', $member->slug)); ?>" class="team-arrow-icon text-decoration-none text-reset">
                                <div class="arrow-circle">
                                    <span class="arrow-icon">↗</span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</section>
<?php endif; ?>


<?php if($page_data->event_status == 'Show'): ?>
<section class="up-coming-events px-3">
    <div class="container py-24">
        <div class="row align-items-center mb-5">
            <div class="col-lg-6 col-md-7">
                <span class="sub-title"><?php echo e($page_data->event_subheading); ?></span>
                <h2 class="main-title"><?php echo nl2br($page_data->event_heading); ?></h2>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="<?php echo e(route('events')); ?>" class="primary-btns hover-icon-reverse">
                    <span class="btn-text-content">
                        <span class="btn-icon-wrapper">
                            <span class="btn-icon"><i class="fa-solid fa-arrow-right"></i></span>
                            <span class="btn-text">View Details</span>
                    </span>
                </a>
            </div>
        </div>

        <div class="row justify-content-center align-items-center">
            <div class="col-12">
                <div class="owl-carousel event-carousel owl-theme">

                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="single-event-card shadow-sm border rounded-4 overflow-hidden bg-white">
                            <div class="thumbnail position-relative overflow-hidden">
                                <a href="<?php echo e(route('event', $event->slug)); ?>">
                                    <img src="<?php echo e(asset('uploads/' . $event->image)); ?>" class="img-fluid w-100" alt="event">
                                </a>
                            </div>
                            <div class="content p-4">
                                <div class="d-flex gap-3 mb-3 text-muted small">
                                    <span><i class="fa-solid fa-location-dot text-primary me-1"></i> <?php echo e($event->event_location); ?></span>
                                    <span><i class="fa-solid fa-calendar-day text-primary me-1"></i> <?php echo e($event->event_date); ?></span>
                                </div>
                                <a href="<?php echo e(route('event', $event->slug)); ?>" class="text-decoration-none text-dark">
                                    <h4 class="title fw-bold mb-4">
                                        <?php echo e($event->title); ?>

                                    </h4>
                                </a>
                                <a href="<?php echo e(route('event', $event->slug)); ?>" class="primary-btns hover-icon-reverse">
                                    <span class="btn-text-content">
                                        <span class="btn-icon-wrapper">
                                            <span class="btn-icon"><i class="fa-solid fa-arrow-right"></i></span>
                                            <span class="btn-text">View Details</span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>



<?php if($page_data->blog_status == 'Show'): ?>
<section class="blogs-section px-3">
    <div class="container py-24">
        <div class="row align-items-center mb-5">
            <div class="col-lg-6 col-md-7">
                <span class="sub-title"><?php echo e($page_data->blog_subheading); ?></span>
                <h2 class="main-title"><?php echo nl2br($page_data->blog_heading); ?></h2>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="blogs.html" class="primary-btns hover-icon-reverse">
                    <span class="btn-text-content">
                        <span class="btn-icon-wrapper">
                            <span class="btn-icon"><i class="fa-solid fa-arrow-right"></i></span>
                            <span class="btn-text">View all Blogs</span>
                    </span>
                </a>
            </div>
        </div>
        <!-- blogs -->
        <div class="row justify-content-center align-items-center">
            <div class="col-12">
                <section class="tmp-blog-area2 inner">
                    <div class="container">
                        <div class="row g-4">
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-4 col-lg-6 col-md-6">
                                <div class="card h-100 border-0 shadow-sm blog-card-style-two rounded-3 overflow-hidden">
                                    <div class="image-section position-relative">
                                        <a href="<?php echo e(route('post',$post->slug)); ?>">
                                            <img src="<?php echo e(asset('uploads/'.$post->image)); ?>"  class="card-img-top img-fluid" alt="<?php echo e($post->title); ?>">
                                        </a>
                                    </div>
                                    <div class="card-body p-4">
                                        <h4 class="card-title fw-bold mb-4">
                                            <a href="<?php echo e(route('post',$post->slug)); ?>" class="text-decoration-none text-dark hover-primary">
                                                <?php echo e($post->title); ?>

                                            </a>
                                        </h4>
                                        <div class="button-area mt-auto">
                                            <a href="<?php echo e(route('post',$post->slug)); ?>" class="btn btn-link p-0 text-decoration-none fw-bold text-primary"> READ MORE <i class="fa-solid fa-arrow-right ms-2"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/home.blade.php ENDPATH**/ ?>