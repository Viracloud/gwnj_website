<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Admin Panel</title>
    <meta name="description" content="">

    <?php echo $__env->make('admin.layouts.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body class="<?php echo e(Request::is('admin/login') || Request::is('admin/forget-password') || Request::is('admin/reset-password*') ? 'login-page' : ''); ?>">


    <?php if(!Request::is('admin/login') && !Request::is('admin/forget-password') && !Request::is('admin/reset-password*')): ?>
    <div class="admin-wrapper">
        
        <!-- Sidebar -->
        <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Mobile overlay -->
        <div id="overlay" class="sidebar-overlay" onclick="toggleSidebar()"></div>

        <!-- Main -->
        <div class="main-wrapper">
            
            <!-- Top bar -->
            <?php echo $__env->make('admin.layouts.top', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Content -->
            <main class="content-area">

                <?php echo $__env->yieldContent('content'); ?>

            </main>
        </div>
    </div>
    <?php else: ?>
    <div class="login-wrapper">
        <div class="login-box">
            
            <?php echo $__env->yieldContent('content'); ?>
            
        </div>
    </div>
    <?php endif; ?>

    <?php echo $__env->make('admin.layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/admin_panel_laravel/resources/views/admin/layouts/master.blade.php ENDPATH**/ ?>