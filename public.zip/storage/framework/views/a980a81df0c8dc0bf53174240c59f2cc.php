<h2>Admin Reset Password</h2>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
    <?php echo e(session('success')); ?>

<?php endif; ?>

<?php if(session('error')): ?>
    <?php echo e(session('error')); ?>

<?php endif; ?>

<form action="<?php echo e(route('admin_reset_password_submit',[$token,$email])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <table>
        <tr>
            <td>Password: </td>
            <td><input type="password" name="password"></td>
        </tr>
        <tr>
            <td>Confirm Password: </td>
            <td><input type="password" name="confirm_password"></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <button type="submit">Submit</button>
            </td>
        </tr>
    </table>
</form><?php /**PATH /Applications/MAMP/htdocs/multi_auth/resources/views/admin/reset-password.blade.php ENDPATH**/ ?>