<?php $__env->startSection('banner'); ?>
<section class="tmp-breadcrumb-area bg-image banner-bg" style="background-image: url(<?php echo e(asset('uploads/'.$global_setting->banner)); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content-main text-center">
                    <h1 class="title text-white fw-bold display-4 mb-3"><?php echo e($page_data->page_title); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb justify-content-center align-items-center mb-0">
                            <li class="breadcrumb-item"><i class="fa-solid fa-house text-primary-orange"></i>
                                <a href="<?php echo e(route('home')); ?>" class="text-white text-decoration-none opacity-75">Home</a>
                            </li>
                            <li class="breadcrumb-item active text-white fw-bold" aria-current="page">
                                <?php echo e($page_data->page_title); ?>

                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape">
        <img src="<?php echo e(asset('uploads/shape-01.png')); ?>" class="shape-1" alt="">
        <img src="<?php echo e(asset('uploads/shape-02.png')); ?>" class="shape-2" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class= "blogs-section px-3 py-5">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-12">
                <section class="tmp-blog-area2 inner py-5">
                    <div class="container">
                        <div class="row g-4">
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-4 col-lg-6 col-md-6">
                                <div class="card h-100 border-0 shadow-sm blog-card-style-two rounded-3 overflow-hidden">
                                    <div class="image-section position-relative">
                                        <a href="<?php echo e(route('post',$post->slug)); ?>">
                                            <img src="<?php echo e(asset('uploads/'.$post->image)); ?>"  class="card-img-top img-fluid" alt="<?php echo e($post->title); ?>">
                                        </a>
                                    </div>
                                    <div class="card-body p-4">
                                        <h4 class="card-title fw-bold mb-4">
                                            <a href="<?php echo e(route('post',$post->slug)); ?>" class="text-decoration-none text-dark hover-primary">
                                                <?php echo e($post->title); ?>

                                            </a>
                                        </h4>
                                        <div class="button-area mt-auto">
                                            <a href="<?php echo e(route('post',$post->slug)); ?>" class="btn btn-link p-0 text-decoration-none fw-bold text-primary"> READ MORE <i class="fa-solid fa-arrow-right ms-2"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <nav class="pagination-area mt-5 pt-4">
                                    <ul class="pagination justify-content-center gap-2 border-0">
                                        
                                        
                                        <?php if($posts->onFirstPage()): ?>
                                            <li class="page-item disabled"><span class="page-link rounded-circle border-0 shadow-sm text-muted"><i class="fa-solid fa-arrow-left"></i></span></li>
                                        <?php else: ?>
                                            <li class="page-item"><a class="page-link rounded-circle border-0 shadow-sm text-dark" href="<?php echo e($posts->previousPageUrl()); ?>"><i class="fa-solid fa-arrow-left"></i></a></li>
                                        <?php endif; ?>

                                        
                                        
                                        <?php $__currentLoopData = $posts->getUrlRange(max(1, $posts->currentPage() - 2), min($posts->lastPage(), $posts->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($page == $posts->currentPage()): ?>
                                                <li class="page-item active"><span class="page-link rounded-circle border-0 shadow-sm"><?php echo e($page); ?></span></li>
                                            <?php else: ?>
                                                <li class="page-item"><a class="page-link rounded-circle border-0 shadow-sm text-dark" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        
                                        <?php if($posts->hasMorePages()): ?>
                                            <li class="page-item"><a class="page-link rounded-circle border-0 shadow-sm text-dark" href="<?php echo e($posts->nextPageUrl()); ?>"><i class="fa-solid fa-arrow-right"></i></a></li>
                                        <?php else: ?>
                                            <li class="page-item disabled"><span class="page-link rounded-circle border-0 shadow-sm text-muted"><i class="fa-solid fa-arrow-right"></i></span></li>
                                        <?php endif; ?>

                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/blog.blade.php ENDPATH**/ ?>