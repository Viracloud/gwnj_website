<?php $__env->startSection('banner'); ?>
<section class="tmp-breadcrumb-area bg-image banner-bg" style="background-image: url(<?php echo e(asset('uploads/'.$global_setting->banner)); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content-main text-center">
                    <h1 class="title text-white fw-bold display-4 mb-3"><?php echo e($member->name); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb justify-content-center align-items-center mb-0">
                            <li class="breadcrumb-item"><i class="fa-solid fa-house text-primary-orange"></i>
                                <a href="<?php echo e(route('home')); ?>" class="text-white text-decoration-none opacity-75">Home</a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('members')); ?>" class="text-white text-decoration-none opacity-75"><?php echo e($page_data->page_title); ?></a>
                            </li>
                            <li class="breadcrumb-item active text-white fw-bold" aria-current="page">
                                <?php echo e($member->name); ?>

                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape">
        <img src="<?php echo e(asset('uploads/shape-01.png')); ?>" class="shape-1" alt="">
        <img src="<?php echo e(asset('uploads/shape-02.png')); ?>" class="shape-2" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="tmp-team-details-area py-5">
    <div class="container py-24 pt-0">
        <div class="section-inner">
            <div class="row g-5 align-items-center mb-5">
                <div class="col-lg-5">
                    <div class="image-section rounded-3 overflow-hidden shadow-sm">
                        <img src="<?php echo e(asset('uploads/'.$member->image)); ?>" class="img-fluid w-100" alt="<?php echo e($member->name); ?>">
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="team-content-area ps-lg-4">
                        <h2 class="main-title mt-0"><?php echo e($member->name); ?></h2>
                        <h5 class="designation text-primary fw-semibold mb-4">
                            <?php echo e($member->designation); ?>

                        </h5>
                        <p class="description mb-4">
                            <?php echo nl2br($member->short_description); ?>

                        </p>

                        <?php if($member->phone != '' || $member->email != '' || $member->experience != ''): ?>
                        <ul class="list-unstyled team-info-list mb-4">
                            <?php if($member->phone != ''): ?>
                            <li class="mb-2 d-flex align-items-center">
                                <span class="fw-bold text-dark me-2">Phone :</span>
                                <a href="tel:+<?php echo e($member->phone); ?>" class="text-decoration-none description"><?php echo e($member->phone); ?></a>
                            </li>
                            <?php endif; ?>
                            <?php if($member->email != ''): ?>
                            <li class="mb-2 d-flex align-items-center">
                                <span class="fw-bold text-dark me-2">Email :</span>
                                <a href="mailto:<?php echo e($member->email); ?>" class="text-decoration-none description"><?php echo e($member->email); ?></a>
                            </li>
                            <?php endif; ?>
                            <?php if($member->experience != ''): ?>
                            <li class="d-flex align-items-center">
                                <span class="fw-bold text-dark me-2">Experience :</span>
                                <span class="description"><?php echo e($member->experience); ?></span>
                            </li>
                            <?php endif; ?>
                        </ul>
                        <?php endif; ?>

                        <?php if($member->facebook != '' || $member->twitter != '' || $member->linkedin != '' || $member->instagram != ''): ?>
                        <div class="social-wrapper d-flex gap-2">
                            <?php if($member->facebook != ''): ?>
                            <a href="<?php echo e($member->facebook); ?>" class="rounded-circle"><i class="fa-brands fa-facebook-f"></i></a>
                            <?php endif; ?>
                            <?php if($member->twitter != ''): ?>
                            <a href="<?php echo e($member->twitter); ?>" class="rounded-circle"><i class="fa-brands fa-twitter"></i></a>
                            <?php endif; ?>
                            <?php if($member->linkedin != ''): ?>
                            <a href="<?php echo e($member->linkedin); ?>" class="rounded-circle"><i class="fa-brands fa-linkedin-in"></i></a>
                            <?php endif; ?>
                            <?php if($member->instagram != ''): ?>
                            <a href="<?php echo e($member->instagram); ?>" class="rounded-circle"><i class="fa-brands fa-instagram"></i></a>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="team-about-area mb-5">
                <h2 class="title fw-bold border-bottom pb-3 mb-4">About Member</h2>
                <div class="description mb-4">
                    <?php echo $member->description; ?>

                </div>
            </div>
            <div class="team-bottom-area py-5">
                <div class="row g-5">
                    <?php if(count($all_skills) > 0): ?>
                    <div class="col-lg-6">
                        <div class="skill-area" id="skills-section">
                            <h2 class="title fw-bold border-bottom pb-3 mb-4">Professional skills</h2>
                            <div class="progress-bar-area">
                                <?php $__currentLoopData = $all_skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-progress mb-4">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="fw-bold text-dark"><?php echo e($skill->name); ?></span>
                                        <span class="fw-bold text-primary percent-value"><?php echo e($skill->percentage); ?>%</span>
                                    </div>
                                    <div class="progress rounded-pill progress-track">
                                        <div class="progress-bar rounded-pill skill-bar progress-fill" role="progressbar" data-width="<?php echo e($skill->percentage); ?>" style="width: <?php echo e($skill->percentage); ?>%" aria-valuenow="<?php echo e($skill->percentage); ?>" aria-valuemin="0" aria-valuemax="100">
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if(count($all_awards) > 0): ?>
                    <div class="col-lg-6">
                        <div class="award-area">
                            <h2 class="title fw-bold border-bottom pb-3 mb-4">Awards & Honor</h2>
                            <div class="row list-unstyled">
                                <?php $__currentLoopData = $all_awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-4">
                                    <div
                                        class="award-item d-flex flex-column text-center align-items-center p-3 mb-3 bg-white rounded-3">
                                        <div class="award-icon">
                                            <img src="<?php echo e(asset('uploads/'.$award->photo)); ?>" alt="<?php echo e($award->name); ?>" style="width:100px;">
                                        </div>
                                        <h5 class="award-title mb-0 award-title-style"><?php echo e($award->name); ?></h5>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/member.blade.php ENDPATH**/ ?>