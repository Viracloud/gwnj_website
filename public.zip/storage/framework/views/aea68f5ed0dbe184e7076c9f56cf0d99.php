<header class="topbar">
    <div class="d-flex align-items-center gap-3">
        <button onclick="toggleSidebar()" class="topbar-btn d-lg-none">
            <i class="fa-solid fa-bars"></i>
        </button>
        <div class="topbar-search hidden-mobile">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" placeholder="Search…">
        </div>
    </div>
    <div class="d-flex align-items-center gap-3">
        <a href="<?php echo e(url('/')); ?>" class="btn-primary-custom">FrontEnd</a>
        <div class="position-relative" id="userDropdown">
            <button onclick="$('#userMenu').toggleClass('show')" class="user-dropdown-btn">
                <img src="<?php echo e(asset('uploads/'.Auth::guard('admin')->user()->photo)); ?>" alt="<?php echo e(Auth::guard('admin')->user()->name); ?>">
                <span class="hidden-mobile"><?php echo e(Auth::guard('admin')->user()->name); ?></span>
                <i class="fa-solid fa-chevron-down"></i>
            </button>
            <div id="userMenu" class="user-dropdown-menu">
                <a href="<?php echo e(route('admin_profile')); ?>" class="text-dark-custom">
                    <i class="fa-regular fa-user"></i>Profile
                </a>
                <a href="<?php echo e(route('admin_logout')); ?>" class="text-danger-custom">
                    <i class="fa-solid fa-right-from-bracket"></i>Logout
                </a>
            </div>
        </div>
    </div>
</header><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/layouts/top.blade.php ENDPATH**/ ?>