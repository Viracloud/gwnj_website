<h2>User Dashboard</h2>

<a href="<?php echo e(route('dashboard')); ?>">Dashboard</a> | <a href="<?php echo e(route('profile')); ?>">Profile</a> | <a href="<?php echo e(route('logout')); ?>">Logout</a>

<hr>

<?php if(session('success')): ?>
    <?php echo e(session('success')); ?>

<?php endif; ?>

<p>Hello <?php echo e(Auth::guard('web')->user()->name); ?>! Welcome to the dashboard.</p><?php /**PATH /Applications/MAMP/htdocs/multi_auth/resources/views/user/dashboard.blade.php ENDPATH**/ ?>