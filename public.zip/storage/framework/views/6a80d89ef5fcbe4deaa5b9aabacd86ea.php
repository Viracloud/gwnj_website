<?php $__env->startSection('banner'); ?>
<section class="tmp-breadcrumb-area bg-image banner-bg" style="background-image: url(<?php echo e(asset('uploads/'.$global_setting->banner)); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content-main text-center">
                    <h1 class="title text-white fw-bold display-4 mb-3">About Us</h1>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb justify-content-center align-items-center mb-0">
                            <li class="breadcrumb-item"><i class="fa-solid fa-house text-primary-orange"></i>
                                <a href="<?php echo e(route('home')); ?>"
                                    class="text-white text-decoration-none opacity-75">Home</a>
                            </li>
                            <li class="breadcrumb-item active text-white fw-bold" aria-current="page">
                                About Us
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape">
        <img src="<?php echo e(asset('uploads/shape-01.png')); ?>" class="shape-1" alt="">
        <img src="<?php echo e(asset('uploads/shape-02.png')); ?>" class="shape-2" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if($page_data->about_status == 'Show'): ?>
<section class="px-3  overflow-hidden">
    <div class="container py-24">
        <div class="row align-items-center g-5">
            <div class="col-md-5">
                <div class="position-relative about-img-wrapper">
                    <img loading="lazy" src="<?php echo e(asset('uploads/shape-01.svg')); ?>" alt="shape" class="position-absolute about-shape1">
                    <img loading="lazy" src="<?php echo e(asset('uploads/'.$about_item->image)); ?>" class="img-fluid rounded-3 position-relative z-1" alt="construction_image">
                    <img loading="lazy" src="<?php echo e(asset('uploads/shape-02.svg')); ?>" alt="shape" class="position-absolute about-shape2">

                    <?php if($about_item->experience_year != '' || $about_item->experience_text != ''): ?>
                    <div class="counter-badge position-absolute bg-white shadow p-4 rounded-3 d-flex align-items-center z-2">
                        <div>
                            <?php if($about_item->experience_year != ''): ?>
                            <h3 class="h2 fw-bold mb-0 text-primary"><?php echo e($about_item->experience_year); ?>+</h3>
                            <?php endif; ?>
                            <?php if($about_item->experience_text != ''): ?>
                            <p class="small text-muted mb-0"><?php echo e($about_item->experience_text); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($about_item->youtube_id != ''): ?>
                    <a href="https://www.youtube.com/watch?v=<?php echo e($about_item->youtube_id); ?>"
                        class="glightbox video-play-btn about-play-btns  mb-4 me-4 z-30 text-decoration-none">
                        <span class="play-icon shadow-lg">
                            <i class="fa-solid fa-play"></i>
                        </span>
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-7">
                <div class="section-title">
                    <?php if($about_item->subheading != ''): ?>
                    <p class="text-primary fw-bold text-uppercase mb-2">
                        <?php echo e($about_item->subheading); ?>

                    </p>
                    <?php endif; ?>
                    <h2 class="main-title fw-600 mb-4">
                        <?php echo nl2br($about_item->heading); ?>

                    </h2>
                    <div class="description">
                        <?php echo nl2br($about_item->text); ?>

                    </div>
                </div>

                <div class="mt-4">
                    <?php if($about_item->phone_text != '' || $about_item->phone_number != ''): ?>
                    <div class="d-flex align-items-center mb-30">
                        <div class="call-icon bg-light p-3 rounded-circle me-3 border">
                            <i class="fa-solid fa-phone-volume text-primary fs-4"></i>
                        </div>
                        <div>
                            <?php if($about_item->phone_text != ''): ?>
                            <p class="text-muted mb-2"><?php echo e($about_item->phone_text); ?></p>
                            <?php endif; ?>
                            <?php if($about_item->phone_number != ''): ?>
                            <a href="tel:<?php echo e($about_item->phone_number); ?>" class="h6 fw-bold text-decoration-none text-dark"><?php echo e($about_item->phone_number); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($about_item->button_link != '' && $about_item->button_text != ''): ?>
                    <a href="<?php echo e($about_item->button_link); ?>" class="primary-btns hover-icon-reverse">
                        <span class="btn-text-content">
                            <span class="btn-icon-wrapper">
                                <span class="btn-icon"><i class="fa-solid fa-phone"></i></span>
                                <span class="btn-text"><?php echo e($about_item->button_text); ?></span>
                            </span>
                        </span>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ========= About section end ======== -->
<?php endif; ?>

<?php if($page_data->service_status == 'Show'): ?>
<!-- ========= service section start ======== -->
<section class="services-section px-3">
    <div class="container py-24">
        <div class="row align-items-center mb-5">
            <div class="col-lg-6 col-md-7">
                <span class="sub-title"><?php echo e($page_data->service_subheading); ?></span>
                <h2 class="main-title"><?php echo nl2br($page_data->service_heading); ?></h2>
            </div>
            <div class="col-lg-5 offset-lg-1 col-md-5 mt-3 mt-md-0">
                <p class="description mb-0">
                    <?php echo nl2br($page_data->service_text); ?>

                </p>
            </div>
        </div>

        <div class="row g-4">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <div class="service-card p-4 h-100">
                    <div class="card-icon mb-4">
                        <img src="<?php echo e(asset('uploads/'.$service->icon)); ?>" alt="Icon" width="55">
                    </div>
                    <h3 class="card-title"><?php echo e($service->title); ?></h3>
                    <p class="card-text"><?php echo nl2br($service->short_description); ?></p>

                    <a href="<?php echo e(route('service',$service->slug)); ?>" class="read-more-btn">
                        <span class="ms-3">Read More</span>
                        <div class="arrow-circle">
                            <span class="arrow-icon">↗</span>
                        </div>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- ========= service section end ======== -->
<?php endif; ?>

<?php if($page_data->testimonial_status == 'Show'): ?>
    <!-- =========  Testimonials section Start ======== -->
<section class="testimonial-area py-5 bg-white position-relative">
    <div class="container py-24">
        <div class="row mb-5 text-center">
            <div class="col-12">
                <p class="sub-title"><?php echo e($page_data->testimonial_subheading); ?></p>
                <h2 class="main-title"><?php echo nl2br($page_data->testimonial_heading); ?></h2>
            </div>
        </div>

        <div class="slider-container-relative position-relative px-md-5">
            <div class="owl-carousel owl-theme testimonial-slider-3">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item  border shadow-sm px-40">
                    <div class="testimonial-card py-50 m-2 bg-white h-100">
                        <div class="author-info d-flex align-items-center mb-4">
                            <img src="<?php echo e(asset('uploads/'.$testimonial->image)); ?>"
                                class="rounded-circle me-3 border-2 border-white shadow-sm size-60"
                                alt="author">
                            <div>
                                <h4 class="mb-0 fw-bold"><?php echo e($testimonial->name); ?></h4>
                                <p class="text-muted mb-0"><?php echo e($testimonial->designation); ?></p>
                            </div>
                        </div>
                        <p class="testimonial-text text-muted mb-3">
                            <?php echo nl2br($testimonial->comment); ?>

                        </p>
                        <div class="star-rating text-warning small">
                            <i class="fas fa-star"></i><i class="fas fa-star"></i><i
                                class="fas fa-star"></i><i class="fas fa-star"></i><i
                                class="fas fa-star"></i>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/about.blade.php ENDPATH**/ ?>