<?php $__env->startSection('banner'); ?>
<section class="tmp-breadcrumb-area bg-image banner-bg" style="background-image: url(<?php echo e(asset('uploads/'.$global_setting->banner)); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content-main text-center">
                    <h1 class="title text-white fw-bold display-4 mb-3"><?php echo e($project->title); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb justify-content-center align-items-center mb-0">
                            <li class="breadcrumb-item"><i class="fa-solid fa-house text-primary-orange"></i>
                                <a href="<?php echo e(route('home')); ?>" class="text-white text-decoration-none opacity-75">Home</a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('projects')); ?>" class="text-white text-decoration-none opacity-75"><?php echo e($page_data->page_title); ?></a>
                            </li>
                            <li class="breadcrumb-item active text-white fw-bold" aria-current="page">
                                <?php echo e($project->title); ?>

                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape">
        <img src="<?php echo e(asset('uploads/shape-01.png')); ?>" class="shape-1" alt="">
        <img src="<?php echo e(asset('uploads/shape-02.png')); ?>" class="shape-2" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="project-details-area py-24 pt-5">
    <div class="container">
        <div class="section-inner">
            <!-- Project Banner -->
            <div class="project-banner mb--50">
                <img src="<?php echo e(asset('uploads/'.$project->image)); ?>" alt="Banner"
                    class="img-fluid w-100 rounded-3">
            </div>

            <div class="row g-5">
                <!-- Main Content Area -->
                <div class="col-lg-8">
                    <div class="content-area pt-4">

                        <div class="description mt-4">
                            <?php echo $project->description; ?>

                        </div>

                        <?php if(count($all_faqs) > 0): ?>
                        <div class="faq-content-area with-box-shadow inner mt-5">
                            <div class="accordion" id="accordionExample">
                                <?php $__currentLoopData = $all_faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item mb-3 border-0 bg-light rounded-3">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed fw-bold bg-transparent shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($loop->iteration); ?>">
                                            <div class="d-flex justify-content-center align-items-center gap-1">
                                                <img class="size-35" src="<?php echo e(asset('uploads/faq.svg')); ?>" alt="icon">
                                                <?php echo e($item->question); ?>

                                            </div>
                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo e($loop->iteration); ?>" class="accordion-collapse collapse"
                                        data-bs-parent="#accordionExample">
                                        <div class="accordion-body text-muted pt-0">
                                            <?php echo nl2br($item->answer); ?>

                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Sticky Sidebar -->
                <div class="col-lg-4 pt-5">
                    <aside class="left-sidebar sticky-top sticky-offset-100">
                        <div class="single-wrapper p-5 rounded-3">
                            <h3 class="title-project-sticky mb--25">About My Project</h3>
                            <ul class="project-info-list p-0">
                                <li><strong>Start Date :</strong> <span><?php echo e($project->start_date); ?></span></li>
                                <li><strong>End Date :</strong> <span><?php echo e($project->end_date); ?></span></li>
                                <li><strong>Location :</strong> <span><?php echo e($project->location); ?></span></li>
                                <li><strong>Manager :</strong> <span><?php echo e($project->manager); ?></span></li>
                                <li><strong>Budget :</strong> <span><?php echo e($project->budget); ?></span></li>
                            </ul>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/project.blade.php ENDPATH**/ ?>