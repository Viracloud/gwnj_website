<nav id="main-nav" class="navbar navbar-expand-lg navbar-dark <?php echo e(request()->is('/') ? 'home-navigation' : 'main-navigation'); ?> py-3">
    <div class="container">
        
        <?php if(request()->is('/')): ?>
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <img class="logo-default" src="<?php echo e(asset('uploads/'.$global_setting->logo_2)); ?>" alt="Construction">
            <img class="logo-sticky" src="<?php echo e(asset('uploads/'.$global_setting->logo_1)); ?>" alt="Construction">
        </a>
        <?php else: ?>
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('uploads/'.$global_setting->logo_1)); ?>" alt="Construction"></a>
        <?php endif; ?>

        <button class="navbar-toggler  border-0 shadow-none" type="button" data-bs-toggle="offcanvas"
            data-bs-target="#drawer-navigation">
                <i class="fa-solid fa-bars toggler-icon-style"></i>
        </button>

        <div class="collapse navbar-collapse gap-3" id="navbarNav">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-center gap-2">
                
                <?php
                $menu_items = App\Models\Menu::where('id',1)->first();
                ?>

                <?php if($menu_items->menu_home_status == 'Show'): ?>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>"><?php echo e($menu_items->menu_home_name); ?></a></li>
                <?php endif; ?>

                <?php if($menu_items->menu_about_status == 'Show'): ?>
                <li class="nav-item"><a class="nav-link  <?php echo e(request()->is('about') ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>"><?php echo e($menu_items->menu_about_name); ?></a></li>
                <?php endif; ?>

                <?php if($menu_items->menu_service_status == 'Show'): ?>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->is('services') ? 'active' : ''); ?>" href="<?php echo e(route('services')); ?>"><?php echo e($menu_items->menu_service_name); ?></a></li>
                <?php endif; ?>

                <?php if($menu_items->menu_event_status == 'Show' || 
                $menu_items->menu_team_member_status == 'Show' || 
                $menu_items->menu_project_status == 'Show' || 
                $menu_items->menu_shop_status == 'Show' || 
                $menu_items->menu_gallery_status == 'Show' || 
                $menu_items->menu_faq_status == 'Show'): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown">Pages</a>
                    <ul class="dropdown-menu border-0">
                        <?php if($menu_items->menu_event_status == 'Show'): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('events')); ?>"><?php echo e($menu_items->menu_event_name); ?></a></li>
                        <?php endif; ?>
                        <?php if($menu_items->menu_team_member_status == 'Show'): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('members')); ?>"><?php echo e($menu_items->menu_team_member_name); ?></a></li>
                        <?php endif; ?>
                        <?php if($menu_items->menu_project_status == 'Show'): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('projects')); ?>"><?php echo e($menu_items->menu_project_name); ?></a></li>
                        <?php endif; ?>
                        <?php if($menu_items->menu_shop_status == 'Show'): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('shop')); ?>"><?php echo e($menu_items->menu_shop_name); ?></a></li>
                        <?php endif; ?>
                        <?php if($menu_items->menu_gallery_status == 'Show'): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('gallery')); ?>"><?php echo e($menu_items->menu_gallery_name); ?></a></li>
                        <?php endif; ?>
                        <?php if($menu_items->menu_faq_status == 'Show'): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('faq')); ?>"><?php echo e($menu_items->menu_faq_name); ?></a></li>
                        <?php endif; ?>
                        <?php
                            $custom_pages = App\Models\CustomPage::get();
                        ?>
                        <?php $__currentLoopData = $custom_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $custom_page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('custom_page', $custom_page->slug)); ?>"><?php echo e($custom_page->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if($menu_items->menu_blog_status == 'Show'): ?>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->is('blog') ? 'active' : ''); ?>" href="<?php echo e(route('blog')); ?>"><?php echo e($menu_items->menu_blog_name); ?></a></li>
                <?php endif; ?>
                
                <?php if($menu_items->menu_contact_status == 'Show'): ?>
                <li class="nav-item me-3"><a class="nav-link" href="<?php echo e(route('contact')); ?>"><?php echo e($menu_items->menu_contact_name); ?></a></li>
                <?php endif; ?>

                <?php if($menu_items->menu_cart_status == 'Show'): ?>
                <li class="nav-item me-4">
                    <div class="text-white cursor-pointer position-relative">
                        <a href="<?php echo e(route('cart')); ?>">
                            <i class="fa-solid fa-cart-plus" id="drawer-cart-icon"></i>
                            <?php if(session()->has('cart')): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger fs-10">
                                <?php echo e(count(session()->get('cart'))); ?>

                            </span>
                            <?php endif; ?>
                        </a>
                    </div>
                </li>
                <?php endif; ?>
            </ul>


            <?php if($menu_items->menu_login_status == 'Show'): ?>
            <?php if(Auth::guard('web')->check()): ?>
            <a href="<?php echo e(route('dashboard')); ?>" class="primary-btns hover-icon-reverse d-md-none d-lg-none d-xl-block">
                <span class="btn-text-content">
                    <span class="btn-icon-wrapper">
                        <span class="btn-text">Dashboard</span>
                    </span>
                </span>
            </a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="primary-btns hover-icon-reverse d-md-none d-lg-none d-xl-block">
                <span class="btn-text-content">
                    <span class="btn-icon-wrapper">
                        <span class="btn-text"><?php echo e($menu_items->menu_login_name); ?></span>
                    </span>
                </span>
            </a>
            <?php endif; ?>
            <?php endif; ?>

        </div>
    </div>
</nav><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/layouts/nav.blade.php ENDPATH**/ ?>