<?php $__env->startSection('banner'); ?>
<section class="tmp-breadcrumb-area bg-image banner-bg" style="background-image: url(<?php echo e(asset('uploads/'.$global_setting->banner)); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content-main text-center">
                    <h1 class="title text-white fw-bold display-4 mb-3"><?php echo e($page_data->page_title); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb justify-content-center align-items-center mb-0">
                            <li class="breadcrumb-item"><i class="fa-solid fa-house text-primary-orange"></i>
                                <a href="<?php echo e(route('home')); ?>"
                                    class="text-white text-decoration-none opacity-75">Home</a>
                            </li>
                            <li class="breadcrumb-item active text-white fw-bold" aria-current="page">
                                <?php echo e($page_data->page_title); ?>

                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape">
        <img src="<?php echo e(asset('uploads/shape-01.png')); ?>" class="shape-1" alt="">
        <img src="<?php echo e(asset('uploads/shape-02.png')); ?>" class="shape-2" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="event-details py-24 pt-5">
    <div class="container">
        <div class="row">
            <div class="row justify-content-center">
            <div class="col-lg-11">
                <div class="events-faqs-area bg-box-shadow">
                    <div class="accordion custom-accordion" id="accordionExample">

                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item mb-3 border-0 bg-light rounded-3">
                            <h2 class="accordion-header">
                                
                                <button class="accordion-button <?php echo e($loop->first ? '' : 'collapsed'); ?> fw-bold bg-transparent shadow-none"
                                    type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($faq->id); ?>">
                                    <div class="d-flex justify-content-center align-items-center gap-1">
                                        <img class="size-35" src="<?php echo e(asset('uploads/faq.svg')); ?>">
                                        <?php echo e($faq->question); ?>

                                    </div>
                                </button>
                            </h2>
                            <div id="collapse<?php echo e($faq->id); ?>" class="accordion-collapse collapse <?php echo e($loop->first ? 'show' : ''); ?>"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body text-muted pt-0">
                                    <?php echo nl2br($faq->answer); ?>

                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
        </div>

        

        
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/faq.blade.php ENDPATH**/ ?>