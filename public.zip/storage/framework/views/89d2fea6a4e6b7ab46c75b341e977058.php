<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-4">
    <div class="page-heading mb-0">
        <h1>Users</h1>
    </div>
    <a href="" class="btn-admin-primary" data-bs-toggle="modal" data-bs-target="#modal_add">
        <i class="fa-solid fa-plus me-1"></i>Add Item
    </a>
</div>

<!-- Add Modal -->
<div class="modal fade" id="modal_add" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-custom">
            <div class="modal-header modal-header-custom">
                <h5 class="modal-title fw-semibold">Add Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-custom">
                <form action="<?php echo e(route('admin_user_store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">Name *</label>
                            <input type="text" class="form-control-custom" name="name">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">Email *</label>
                            <input type="email" class="form-control-custom" name="email">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">Phone</label>
                            <input type="text" class="form-control-custom" name="phone">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">Address</label>
                            <input type="text" class="form-control-custom" name="address">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">Country</label>
                            <input type="text" class="form-control-custom" name="country">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">State</label>
                            <input type="text" class="form-control-custom" name="state">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">City</label>
                            <input type="text" class="form-control-custom" name="city">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">Zip</label>
                            <input type="text" class="form-control-custom" name="zip">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">Password *</label>
                            <input type="password" class="form-control-custom" name="password">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">Confirm Password *</label>
                            <input type="password" class="form-control-custom" name="confirm_password">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="label-custom">Status</label>
                            <select class="form-control-custom" name="status">
                                <option value="1">Verified</option>
                                <option value="0">Not Verified</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn-admin-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- // Add Modal -->


<div class="card-custom-p5">
    <table id="dataTable" class="table-dt stripe hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <?php if($user->email_verified_at != null): ?>
                    <span class="badge bg-success">Verified</span>
                    <?php else: ?>
                    <span class="badge bg-danger">Not Verified</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="d-flex align-items-center gap-1">
                        <a class="btn-icon btn-icon-edit btn-edit-row" data-bs-toggle="modal" data-bs-target="#modal_edit_<?php echo e($loop->iteration); ?>"><i class="fa-solid fa-pen-to-square text-xs"></i></a>
                        <a class="btn-icon btn-icon-delete" data-bs-toggle="modal" data-bs-target="#modal_delete_<?php echo e($loop->iteration); ?>"><i class="fa-solid fa-trash text-xs"></i></a>
                    </div>
                </td>
            </tr>
            <!-- Edit Modal -->
            <div class="modal fade" id="modal_edit_<?php echo e($loop->iteration); ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content modal-content-custom">
                        <div class="modal-header modal-header-custom">
                            <h5 class="modal-title fw-semibold">Edit Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body modal-body-custom">
                            <form action="<?php echo e(route('admin_user_update', $user->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">Name *</label>
                                        <input type="text" class="form-control-custom" name="name" value="<?php echo e($user->name); ?>">
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">Email *</label>
                                        <input type="email" class="form-control-custom" name="email" value="<?php echo e($user->email); ?>">
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">Phone</label>
                                        <input type="text" class="form-control-custom" name="phone" value="<?php echo e($user->phone); ?>">
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">Address</label>
                                        <input type="text" class="form-control-custom" name="address" value="<?php echo e($user->address); ?>">
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">Country</label>
                                        <input type="text" class="form-control-custom" name="country" value="<?php echo e($user->country); ?>">
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">State</label>
                                        <input type="text" class="form-control-custom" name="state" value="<?php echo e($user->state); ?>">
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">City</label>
                                        <input type="text" class="form-control-custom" name="city" value="<?php echo e($user->city); ?>">
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">Zip</label>
                                        <input type="text" class="form-control-custom" name="zip" value="<?php echo e($user->zip); ?>">
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">Password</label>
                                        <input type="password" class="form-control-custom" name="password">
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">Confirm Password</label>
                                        <input type="password" class="form-control-custom" name="confirm_password">
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="label-custom">Status</label>
                                        <select class="form-control-custom" name="status">
                                            <option value="1" <?php if($user->email_verified_at != null): ?> selected <?php endif; ?>>Verified</option>
                                            <option value="0" <?php if($user->email_verified_at == null): ?> selected <?php endif; ?>>Not Verified</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <button type="submit" class="btn-admin-primary">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- // Edit Modal -->

            <!-- Delete Modal -->
            <div class="modal fade" id="modal_delete_<?php echo e($loop->iteration); ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content modal-content-custom">
                        <div class="modal-header modal-header-custom">
                            <h5 class="modal-title fw-semibold">Delete Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body modal-body-custom">
                            <form action="<?php echo e(route('admin_user_delete', $user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <p>
                                        Are you sure you want to delete this item?
                                    </p>
                                </div>
                                <div class="mb-3">
                                    <button type="submit" class="btn-admin-delete">Delete</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- // Delete Modal -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/user/index.blade.php ENDPATH**/ ?>