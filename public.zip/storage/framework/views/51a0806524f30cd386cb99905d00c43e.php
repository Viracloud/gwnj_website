<?php $__env->startSection('banner'); ?>
<section class="tmp-breadcrumb-area bg-image banner-bg" style="background-image: url(<?php echo e(asset('uploads/'.$global_setting->banner)); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content-main text-center">
                    <h1 class="title text-white fw-bold display-4 mb-3"><?php echo e($page_data->page_title); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb justify-content-center align-items-center mb-0">
                            <li class="breadcrumb-item"><i class="fa-solid fa-house text-primary-orange"></i>
                                <a href="<?php echo e(route('home')); ?>" class="text-white text-decoration-none opacity-75">Home</a>
                            </li>
                            <li class="breadcrumb-item active text-white fw-bold" aria-current="page">
                                <?php echo e($page_data->page_title); ?>

                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape">
        <img src="<?php echo e(asset('uploads/shape-01.png')); ?>" class="shape-1" alt="">
        <img src="<?php echo e(asset('uploads/shape-02.png')); ?>" class="shape-2" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="team-area px-3">
    <div class="container py-24">
        <div class="row g-4">
            
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6">
                <div class="team-card-v2">
                    <div class="image-section">
                        <a href="<?php echo e(route('member', $member->slug)); ?>">
                            <img src="<?php echo e(asset('uploads/'.$member->image)); ?>" class="img-fluid w-100"
                                alt="<?php echo e($member->name); ?>">
                        </a>
                        <div class="social-wrapper">
                            <ul class="list-unstyled mb-0 d-flex justify-content-center gap-2">
                                <?php if($member->facebook != ''): ?>
                                <li>
                                    <a href="<?php echo e($member->facebook); ?>"><i class="fa-brands fa-facebook-f"></i></a>
                                </li>
                                <?php endif; ?>
                                <?php if($member->twitter != ''): ?>
                                <li>
                                    <a href="<?php echo e($member->twitter); ?>"><i class="fa-brands fa-twitter"></i></a>
                                </li>
                                <?php endif; ?>
                                <?php if($member->linkedin != ''): ?>
                                <li>
                                    <a href="<?php echo e($member->linkedin); ?>"><i class="fa-brands fa-linkedin-in"></i></a>
                                </li>
                                <?php endif; ?>
                                <?php if($member->instagram != ''): ?>
                                <li>
                                    <a href="<?php echo e($member->instagram); ?>"><i class="fa-brands fa-instagram"></i></a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="content-area position-relative content-area-padding">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h5 class="title mb-2">
                                    <a href="<?php echo e(route('member', $member->slug)); ?>" class="title text-reset text-decoration-none fw-bold"><?php echo e($member->name); ?></a>
                                </h5>
                                <p class="designation text-muted mb-1"><?php echo e($member->designation); ?></p>
                            </div>
                            <a href="<?php echo e(route('member', $member->slug)); ?>" class="team-arrow-icon text-decoration-none text-reset">
                                <div class="arrow-circle">
                                    <span class="arrow-icon">↗</span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>

        <div class="row">
            <div class="col-lg-12">
                <nav class="pagination-area mt-5 pt-4">
                    <ul class="pagination justify-content-center gap-2 border-0">
                        
                        
                        <?php if($members->onFirstPage()): ?>
                            <li class="page-item disabled"><span class="page-link rounded-circle border-0 shadow-sm text-muted"><i class="fa-solid fa-arrow-left"></i></span></li>
                        <?php else: ?>
                            <li class="page-item"><a class="page-link rounded-circle border-0 shadow-sm text-dark" href="<?php echo e($members->previousPageUrl()); ?>"><i class="fa-solid fa-arrow-left"></i></a></li>
                        <?php endif; ?>

                        
                        
                        <?php $__currentLoopData = $members->getUrlRange(max(1, $members->currentPage() - 2), min($members->lastPage(), $members->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $members->currentPage()): ?>
                                <li class="page-item active"><span class="page-link rounded-circle border-0 shadow-sm"><?php echo e($page); ?></span></li>
                            <?php else: ?>
                                <li class="page-item"><a class="page-link rounded-circle border-0 shadow-sm text-dark" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php if($members->hasMorePages()): ?>
                            <li class="page-item"><a class="page-link rounded-circle border-0 shadow-sm text-dark" href="<?php echo e($members->nextPageUrl()); ?>"><i class="fa-solid fa-arrow-right"></i></a></li>
                        <?php else: ?>
                            <li class="page-item disabled"><span class="page-link rounded-circle border-0 shadow-sm text-muted"><i class="fa-solid fa-arrow-right"></i></span></li>
                        <?php endif; ?>

                    </ul>
                </nav>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/members.blade.php ENDPATH**/ ?>