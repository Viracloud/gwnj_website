<?php $__env->startSection('content'); ?>
<!-- Greeting -->
<div class="page-heading">
    <h1>Welcome back, <?php echo e(Auth::guard('admin')->user()->name); ?> 👋</h1>
    <p>Here's what's happening today.</p>
</div>

<!-- Stat Cards -->
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom">
            <div class="d-flex align-items-center gap-3">
                <div class="icon-box bg-blue-100 text-primary-600">
                    <i class="fa-solid fa-dollar-sign"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500 mb-0">Total Revenue</p>
                    <p class="text-2xl fw-bold mb-0">$<?php echo e(number_format($total_revenue, 2)); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom">
            <div class="d-flex align-items-center gap-3">
                <div class="icon-box bg-purple-100 text-purple-600">
                    <i class="fa-solid fa-bag-shopping"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500 mb-0">Total Orders</p>
                    <p class="text-2xl fw-bold mb-0"><?php echo e(number_format($total_orders)); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom">
            <div class="d-flex align-items-center gap-3">
                <div class="icon-box bg-orange-100 text-orange-600">
                    <i class="fa-solid fa-users"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500 mb-0">Total Customers</p>
                    <p class="text-2xl fw-bold mb-0"><?php echo e(number_format($total_customers)); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="card-custom">
            <div class="d-flex align-items-center gap-3">
                <div class="icon-box bg-green-100 text-green-600">
                    <i class="fa-solid fa-envelope-open-text"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500 mb-0">Total Subscribers</p>
                    <p class="text-2xl fw-bold mb-0"><?php echo e(number_format($total_subscribers)); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Sales Chart -->
<div class="card-custom-p5 mb-4">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <h2 class="section-title mb-0">Daily Sales — <?php echo e(now()->format('F Y')); ?></h2>
    </div>
    <div class="chart-container">
        <canvas id="salesChart"></canvas>
    </div>
</div>

<!-- Recent Orders -->
<div class="card-custom-static">
    <div class="d-flex align-items-center justify-content-between p-4 pb-0">
        <h2 class="section-title mb-0">Recent Orders</h2>
        <a href="<?php echo e(route('admin_order_orders')); ?>" class="text-sm text-primary-600 hover-underline text-decoration-none">View all</a>
    </div>
    <div class="overflow-x-auto">
        <table class="table-custom mt-3">
            <thead>
                <tr>
                    <th>Order</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recent_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-medium">#<?php echo e($order->order_no); ?></td>
                    <td><?php echo e($order->user?->name ?? 'N/A'); ?></td>
                    <td>$<?php echo e(number_format($order->final_amount, 2)); ?></td>
                    <td>
                        <?php if($order->status == 'Completed'): ?>
                        <span class="badge-status completed">Payment Completed</span>
                        <?php elseif($order->status == 'Processing'): ?>
                        <span class="badge-status processing">Processing</span>
                        <?php elseif($order->status == 'Shipped'): ?>
                        <span class="badge-status shipped">Shipped</span>
                        <?php elseif($order->status == 'Cancelled'): ?>
                        <span class="badge-status cancelled">Cancelled</span>
                        <?php elseif($order->status == 'Delivered'): ?>
                        <span class="badge-status delivered">Delivered</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">No orders yet.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    var days = <?php echo json_encode($chart_labels, 15, 512) ?>;
    var sales = <?php echo json_encode($chart_data, 15, 512) ?>;

    if ($('#salesChart').length) {
        new Chart($('#salesChart')[0], {
            type: 'bar',
            data: {
                labels: days,
                datasets: [{
                    label: 'Sales ($)',
                    data: sales,
                    backgroundColor: '#2563eb',
                    hoverBackgroundColor: '#1d4ed8',
                    borderRadius: 4,
                    barPercentage: 0.6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            title: (t) => 'Day ' + t[0].label,
                            label: (t) => ' $' + t.raw.toLocaleString()
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#f1f5f9' },
                        ticks: { font: { size: 11 }, callback: v => '$' + v }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { font: { size: 11 } }
                    }
                }
            }
        });
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>