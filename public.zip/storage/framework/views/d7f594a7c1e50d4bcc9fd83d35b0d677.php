<h2>Admin Dashboard</h2>

<a href="<?php echo e(route('admin_dashboard')); ?>">Dashboard</a> | <a href="<?php echo e(route('admin_profile')); ?>">Profile</a> | <a href="<?php echo e(route('admin_logout')); ?>">Logout</a>

<hr>

<?php if(session('success')): ?>
    <?php echo e(session('success')); ?>

<?php endif; ?>

<p>Hello <?php echo e(Auth::guard('admin')->user()->name); ?>! Welcome to the dashboard.</p><?php /**PATH /Applications/MAMP/htdocs/multi_auth/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>