<a href="<?php echo e(route('home')); ?>">Home</a> | <a href="<?php echo e(route('about')); ?>">About</a> | <a href="<?php echo e(route('login')); ?>">Login</a> | <a href="<?php echo e(route('register')); ?>">Register</a>

<h1>User Forget Password</h1>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
    <?php echo e(session('success')); ?>

<?php endif; ?>

<?php if(session('error')): ?>
    <?php echo e(session('error')); ?>

<?php endif; ?>

<form action="<?php echo e(route('forget_password_submit')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <table>
        <tr>
            <td>Email: </td>
            <td><input type="text" name="email" placeholder="Email"></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <button type="submit">Submit</button>
                <div><a href="<?php echo e(route('login')); ?>">Back to login page</a></div>
            </td>
        </tr>
    </table>
</form><?php /**PATH /Applications/MAMP/htdocs/multi_auth/resources/views/front/forget-password.blade.php ENDPATH**/ ?>