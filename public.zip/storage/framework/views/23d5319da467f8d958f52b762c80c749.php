<?php $__env->startSection('banner'); ?>
<section class="tmp-breadcrumb-area bg-image banner-bg" style="background-image: url(<?php echo e(asset('uploads/'.$global_setting->banner)); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content-main text-center">
                    <h1 class="title text-white fw-bold display-4 mb-3"><?php echo e($page_data->reviews_page_title); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb justify-content-center align-items-center mb-0">
                            <li class="breadcrumb-item"><i class="fa-solid fa-house text-primary-orange"></i>
                                <a href="<?php echo e(route('home')); ?>" class="text-white text-decoration-none opacity-75">Home</a>
                            </li>
                            <li class="breadcrumb-item active text-white fw-bold" aria-current="page">
                                <?php echo e($page_data->reviews_page_title); ?>

                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape">
        <img src="<?php echo e(asset('uploads/shape-01.png')); ?>" class="shape-1" alt="">
        <img src="<?php echo e(asset('uploads/shape-02.png')); ?>" class="shape-2" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="user-dashboard-section-start py-5">
    <div class="container">
        <div class="row g-5">
            <!-- Sidebar Column -->
            <div class="col-lg-3">
                <div class="user-infor-left-sidebar-dashboard">
                    <div class="dashboard-menu-section">
                        <nav class="dashboard-mainmenu">
                            <?php echo $__env->make('user.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </nav>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-lg-9">
                <div class="dash-board-content-area-wrappper">
                    <div class="single-card-dashboard shadow-sm bg-white p-4 rounded-3">
                        <h3 class="order-title mb-4">Reviews</h3>

                        <div class="table-responsive">
                            <table class="table table-borderless align-middle custom-order-table">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>See Product</th>
                                        <th>Rating</th>
                                        <th>Comment</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($review->product->name); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('product', $review->product->slug)); ?>">See Product</a>
                                        </td>
                                        <td><?php echo e($review->rating); ?></td>
                                        <td><?php echo e($review->comment); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/user/reviews.blade.php ENDPATH**/ ?>