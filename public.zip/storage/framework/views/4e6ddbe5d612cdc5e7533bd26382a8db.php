<?php $__env->startSection('banner'); ?>
<section class="tmp-breadcrumb-area bg-image banner-bg" style="background-image: url(<?php echo e(asset('uploads/'.$global_setting->banner)); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-content-main text-center">
                    <h1 class="title text-white fw-bold display-4 mb-3"><?php echo e($page_data->page_title); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb justify-content-center align-items-center mb-0">
                            <li class="breadcrumb-item"><i class="fa-solid fa-house text-primary-orange"></i>
                                <a href="<?php echo e(route('home')); ?>" class="text-white text-decoration-none opacity-75">Home</a>
                            </li>
                            <li class="breadcrumb-item active text-white fw-bold" aria-current="page">
                                <?php echo e($page_data->page_title); ?>

                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape">
        <img src="<?php echo e(asset('uploads/shape-01.png')); ?>" class="shape-1" alt="">
        <img src="<?php echo e(asset('uploads/shape-02.png')); ?>" class="shape-2" alt="">
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="up-coming-events px-3">
    <div class="container py-24">
        <div class="row g-4">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <div class="item h-100">
                    <div class="single-event-card shadow-sm border rounded-4 overflow-hidden bg-white">
                        <div class="thumbnail position-relative overflow-hidden">
                            <a href="<?php echo e(route('event', $event->slug)); ?>">
                                <img src="<?php echo e(asset('uploads/' . $event->image)); ?>" class="img-fluid w-100" alt="event">
                            </a>
                        </div>
                        <div class="content p-4">
                            <div class="d-flex gap-3 mb-3 text-muted small">
                                <span><i class="fa-solid fa-location-dot text-primary me-1"></i> <?php echo e($event->event_location); ?></span>
                                <span><i class="fa-solid fa-calendar-day text-primary me-1"></i> <?php echo e($event->event_date); ?></span>
                            </div>
                            <a href="<?php echo e(route('event', $event->slug)); ?>" class="text-decoration-none text-dark">
                                <h4 class="title fw-bold mb-4">
                                    <?php echo e($event->title); ?>

                                </h4>
                            </a>
                            <a href="<?php echo e(route('event', $event->slug)); ?>" class="primary-btns hover-icon-reverse">
                                <span class="btn-text-content">
                                    <span class="btn-icon-wrapper">
                                        <span class="btn-icon"><i class="fa-solid fa-arrow-right"></i></span>
                                        <span class="btn-text">View Details</span>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-12">
                <nav class="pagination-area mt-5 pt-4">
                    <ul class="pagination justify-content-center gap-2 border-0">
                        
                        
                        <?php if($events->onFirstPage()): ?>
                            <li class="page-item disabled"><span class="page-link rounded-circle border-0 shadow-sm text-muted"><i class="fa-solid fa-arrow-left"></i></span></li>
                        <?php else: ?>
                            <li class="page-item"><a class="page-link rounded-circle border-0 shadow-sm text-dark" href="<?php echo e($events->previousPageUrl()); ?>"><i class="fa-solid fa-arrow-left"></i></a></li>
                        <?php endif; ?>

                        
                        
                        <?php $__currentLoopData = $events->getUrlRange(max(1, $events->currentPage() - 2), min($events->lastPage(), $events->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $events->currentPage()): ?>
                                <li class="page-item active"><span class="page-link rounded-circle border-0 shadow-sm"><?php echo e($page); ?></span></li>
                            <?php else: ?>
                                <li class="page-item"><a class="page-link rounded-circle border-0 shadow-sm text-dark" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php if($events->hasMorePages()): ?>
                            <li class="page-item"><a class="page-link rounded-circle border-0 shadow-sm text-dark" href="<?php echo e($events->nextPageUrl()); ?>"><i class="fa-solid fa-arrow-right"></i></a></li>
                        <?php else: ?>
                            <li class="page-item disabled"><span class="page-link rounded-circle border-0 shadow-sm text-muted"><i class="fa-solid fa-arrow-right"></i></span></li>
                        <?php endif; ?>

                    </ul>
                </nav>
            </div>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/events.blade.php ENDPATH**/ ?>