<ul>
    <li>
        <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>"><i class="fa-regular fa-user"></i> Dashboard</a>
    </li>
    <li>
        <a href="<?php echo e(route('profile')); ?>" class="<?php echo e(request()->routeIs('profile') ? 'active' : ''); ?>"><i class="fa-regular fa-pen-to-square"></i> Profile</a>
        </li>
    <li>
        <a href="<?php echo e(route('orders')); ?>" class="<?php echo e(request()->routeIs('orders') || request()->routeIs('invoice') ? 'active' : ''); ?>"><i class="fa-regular fa-bag-shopping"></i> My Orders</a>
    </li>
    <li>
        <a href="<?php echo e(route('reviews')); ?>" class="<?php echo e(request()->routeIs('reviews') ? 'active' : ''); ?>"><i class="fa-regular fa-star"></i> My Reviews</a>
    </li>
    <li>
        <a href="<?php echo e(route('wishlist')); ?>" class="<?php echo e(request()->routeIs('wishlist') ? 'active' : ''); ?>"><i class="fa-regular fa-heart"></i> Wishlist</a>
    </li>
    <li>
        <a href="<?php echo e(route('logout')); ?>" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a>
    </li>
</ul><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/user/sidebar.blade.php ENDPATH**/ ?>