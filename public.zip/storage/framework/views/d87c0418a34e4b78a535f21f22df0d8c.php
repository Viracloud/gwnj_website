<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-4">
    <div class="page-heading mb-0">
        <h1>Projects</h1>
    </div>
    <a href="" class="btn-admin-primary" data-bs-toggle="modal" data-bs-target="#modal_add">
        <i class="fa-solid fa-plus me-1"></i>Add Item
    </a>
</div>

<!-- Add Modal -->
<div class="modal fade" id="modal_add" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-custom">
            <div class="modal-header modal-header-custom">
                <h5 class="modal-title fw-semibold">Add Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-custom">
                <form action="<?php echo e(route('admin_project_store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="label-custom">Select Image *</label>
                        <input type="file" class="form-control-custom" name="image">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Title *</label>
                        <input type="text" class="form-control-custom" name="title">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Slug *</label>
                        <input type="text" class="form-control-custom" name="slug">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Short Description *</label>
                        <textarea class="form-control-custom" name="short_description" rows="4"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Description *</label>
                        <textarea id="editor1" class="form-control-custom" name="description" rows="4"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Show on Home?</label>
                        <select class="form-control-custom" name="show_on_home">
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Start Date</label>
                        <input type="text" class="form-control-custom" name="start_date">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">End Date</label>
                        <input type="text" class="form-control-custom" name="end_date">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Location</label>
                        <input type="text" class="form-control-custom" name="location">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Manager</label>
                        <input type="text" class="form-control-custom" name="manager">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Budget</label>
                        <input type="text" class="form-control-custom" name="budget">
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn-admin-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- // Add Modal -->


<div class="card-custom-p5">
    <table id="dataTable" class="table-dt stripe hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Title</th>
                <th>Show on Home?</th>
                <th>FAQs</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td>
                    <img src="<?php echo e(asset('uploads/'.$project->image)); ?>" alt="" class="w_200">
                </td>
                <td><?php echo e($project->title); ?></td>
                <td>
                    <?php if($project->show_on_home == 'Yes'): ?>
                    <span class="badge bg-success">Yes</span>
                    <?php else: ?>
                    <span class="badge bg-danger">No</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('admin_project_faqs', $project->id)); ?>" class="btn btn-warning btn-sm">Manage FAQs</a>
                </td>
                <td>
                    <div class="d-flex align-items-center gap-1">
                        <a class="btn-icon btn-icon-edit btn-edit-row" data-bs-toggle="modal" data-bs-target="#modal_edit_<?php echo e($loop->iteration); ?>"><i class="fa-solid fa-pen-to-square text-xs"></i></a>
                        <a class="btn-icon btn-icon-delete" data-bs-toggle="modal" data-bs-target="#modal_delete_<?php echo e($loop->iteration); ?>"><i class="fa-solid fa-trash text-xs"></i></a>
                    </div>
                </td>
            </tr>
            <!-- Edit Modal -->
            <div class="modal fade" id="modal_edit_<?php echo e($loop->iteration); ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content modal-content-custom">
                        <div class="modal-header modal-header-custom">
                            <h5 class="modal-title fw-semibold">Edit Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body modal-body-custom">
                            <form action="<?php echo e(route('admin_project_update', $project->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label class="label-custom">Existing Image</label>
                                    <div>
                                        <img src="<?php echo e(asset('uploads/'.$project->image)); ?>" alt="" class="w_150">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Change Image</label>
                                    <input type="file" class="form-control-custom" name="image">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Title *</label>
                                    <input type="text" class="form-control-custom" name="title" value="<?php echo e($project->title); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Slug *</label>
                                    <input type="text" class="form-control-custom" name="slug" value="<?php echo e($project->slug); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Short Description *</label>
                                    <textarea class="form-control-custom" name="short_description" rows="4"><?php echo e($project->short_description); ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Description *</label>
                                    <textarea id="editor1" class="form-control-custom" name="description" rows="4"><?php echo e($project->description); ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Show on Home?</label>
                                    <select class="form-control-custom" name="show_on_home">
                                        <option value="Yes" <?php echo e($project->show_on_home == 'Yes' ? 'selected' : ''); ?>>Yes</option>
                                        <option value="No" <?php echo e($project->show_on_home == 'No' ? 'selected' : ''); ?>>No</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Start Date</label>
                                    <input type="text" class="form-control-custom" name="start_date" value="<?php echo e($project->start_date); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">End Date</label>
                                    <input type="text" class="form-control-custom" name="end_date" value="<?php echo e($project->end_date); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Location</label>
                                    <input type="text" class="form-control-custom" name="location" value="<?php echo e($project->location); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Manager</label>
                                    <input type="text" class="form-control-custom" name="manager" value="<?php echo e($project->manager); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Budget</label>
                                    <input type="text" class="form-control-custom" name="budget" value="<?php echo e($project->budget); ?>">
                                </div>
                                <div class="mb-3">
                                    <button type="submit" class="btn-admin-primary">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- // Edit Modal -->

            <!-- Delete Modal -->
            <div class="modal fade" id="modal_delete_<?php echo e($loop->iteration); ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content modal-content-custom">
                        <div class="modal-header modal-header-custom">
                            <h5 class="modal-title fw-semibold">Delete Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body modal-body-custom">
                            <form action="<?php echo e(route('admin_project_delete', $project->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <p>
                                        Are you sure you want to delete this item?
                                    </p>
                                </div>
                                <div class="mb-3">
                                    <button type="submit" class="btn-admin-delete">Delete</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- // Delete Modal -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/project/index.blade.php ENDPATH**/ ?>