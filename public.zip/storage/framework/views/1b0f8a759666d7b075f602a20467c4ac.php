<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1>Settings - Top Bar</h1>
</div>

<form action="<?php echo e(route('admin_setting_top_bar_update')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row g-4">
        <div class="col-12 col-xl-12">

            <h6 class="cus-heading">Contact Information</h6>
            <div class="card-custom-p mb-4">
                <div class="mb-3">
                    <label class="label-custom">Email</label>
                    <input type="text" name="top_bar_email" value="<?php echo e($setting->top_bar_email); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Phone</label>
                    <input type="text" name="top_bar_phone" value="<?php echo e($setting->top_bar_phone); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Address</label>
                    <input type="text" name="top_bar_address" value="<?php echo e($setting->top_bar_address); ?>" class="form-control-custom">
                </div>
            </div>

            <h6 class="cus-heading">Social Links</h6>
            <div class="card-custom-p mb-4">
                <div class="mb-3">
                    <label class="label-custom">Facebook URL</label>
                    <input type="text" name="top_bar_facebook" value="<?php echo e($setting->top_bar_facebook); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Twitter URL</label>
                    <input type="text" name="top_bar_twitter" value="<?php echo e($setting->top_bar_twitter); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">LinkedIn URL</label>
                    <input type="text" name="top_bar_linkedin" value="<?php echo e($setting->top_bar_linkedin); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Instagram URL</label>
                    <input type="text" name="top_bar_instagram" value="<?php echo e($setting->top_bar_instagram); ?>" class="form-control-custom">
                </div>
            </div>

            <div class="card-custom-p mb-4">
                <div>
                    <button type="submit" class="btn-admin-primary">Update</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/setting/top_bar.blade.php ENDPATH**/ ?>