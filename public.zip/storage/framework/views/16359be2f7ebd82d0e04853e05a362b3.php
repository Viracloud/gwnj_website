<a href="<?php echo e(route('home')); ?>">Home</a> | <a href="<?php echo e(route('about')); ?>">About</a> | <a href="<?php echo e(route('login')); ?>">Login</a> | <a href="<?php echo e(route('register')); ?>">Register</a>

<h1>Login Page</h1><?php /**PATH /Applications/MAMP/htdocs/multi_auth/resources/views/user/login.blade.php ENDPATH**/ ?>