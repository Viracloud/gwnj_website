<?php $__env->startSection('content'); ?>
<!-- Logo -->
<div class="text-center mb-4">
    <h1 class="login-title">Reset Password</h1>
    <p class="login-subtitle">Enter your new password below.</p>
</div>

<!-- Form -->
<form action="<?php echo e(route('admin_reset_password_submit',[$token,$email])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label class="label-custom">New Password</label>
        <div class="login-input-wrap">
            <i class="fa-solid fa-lock"></i>
            <input type="password" name="password" class="form-control-custom" placeholder="********">
        </div>
    </div>
    <div class="mb-3">
        <label class="label-custom">Confirm Password</label>
        <div class="login-input-wrap">
            <i class="fa-solid fa-lock"></i>
            <input type="password" name="confirm_password" class="form-control-custom" placeholder="********">
        </div>
    </div>
    <button type="submit" class="btn-login w-100">Reset Password</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/admin_panel_laravel/resources/views/admin/reset-password.blade.php ENDPATH**/ ?>