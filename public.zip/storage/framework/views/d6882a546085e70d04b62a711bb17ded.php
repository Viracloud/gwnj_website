<!DOCTYPE html>
<html class="no-js" lang="en" <?php if($global_setting->layout_direction == 'rtl'): ?> dir="rtl" <?php endif; ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <?php if(Request::is('/')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('about')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('services') || Request::is('service/*')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('projects') || Request::is('project/*')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('events') || Request::is('event/*')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('blog') || Request::is('post/*')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('team-members') || Request::is('team-member/*')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('gallery')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('faq')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('login') || Request::is('register') || Request::is('forget-password') || Request::is('reset-password/*')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('dashboard') || Request::is('profile') || Request::is('orders') || Request::is('invoice/*') || Request::is('reviews') || Request::is('wishlist')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('terms-of-use')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('privacy-policy')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>
    
    <?php if(Request::is('contact')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('shop') || Request::is('product/*')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('cart') || Request::is('checkout')): ?>
        <title><?php echo e($page_data->seo_title); ?></title>
        <meta name="description" content="<?php echo e($page_data->seo_meta_description); ?>">
    <?php endif; ?>

    <?php if(Request::is('page/*')): ?>
        <?php
            $slug = request()->segment(2);
            $custom_page = App\Models\CustomPage::where('slug', $slug)->first();
        ?>
        <title><?php echo e($custom_page->seo_title); ?></title>
        <meta name="description" content="<?php echo e($custom_page->seo_meta_description); ?>">
    <?php endif; ?>

    <link rel="icon" type="image/png" href="<?php echo e(asset('uploads/'.$global_setting->favicon)); ?>">

    <link href="https://fonts.googleapis.com/css2?family=Exo:wght@400;700&family=Rubik:wght@400;700&display=swap" rel="stylesheet">

    <?php echo $__env->make('front.layouts.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if($global_setting->layout_direction == 'rtl'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('dist-front/css/rtl.css')); ?>">
    <?php endif; ?>

    <style>
        :root {
            --primary-color: <?php echo e($global_setting->theme_color); ?>;
        }
        .text-primary-orange {
            color: <?php echo e($global_setting->theme_color); ?> !important;
        }
        .about-img-wrapper::before,
        .about-img-wrapper::after,
        .tmp-team-details-area .social-wrapper a:hover,
        .product-tab-btn.active,
        .reply-link,
        .post-comment-btn {
            background-color: <?php echo e($global_setting->theme_color); ?> !important;
        }
        .product-tab-btn:hover,
        .tmp-breadcrumb-area a:hover,
        .category-link:hover {
            color: <?php echo e($global_setting->theme_color); ?> !important;
        }
        .reply-input:focus,
        .product-thumb:hover {
            border-color: <?php echo e($global_setting->theme_color); ?> !important;
        }
    </style>

</head>
<body>
    <header>
        <?php echo $__env->make('front.layouts.top', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('front.layouts.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('front.layouts.mobile-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->yieldContent('banner'); ?>
    </header>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('front.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('front.layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/layouts/master.blade.php ENDPATH**/ ?>