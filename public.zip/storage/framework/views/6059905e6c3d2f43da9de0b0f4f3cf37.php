<?php if($global_setting->layout_direction == 'rtl'): ?>
<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/bootstrap.rtl.min.css')); ?>">
<?php else: ?>
<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/bootstrap.min.css')); ?>">
<?php endif; ?>
<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/bootstrap-icons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/glightbox.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-admin/css/iziToast.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist-front/css/responsive.css')); ?>"><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/front/layouts/styles.blade.php ENDPATH**/ ?>