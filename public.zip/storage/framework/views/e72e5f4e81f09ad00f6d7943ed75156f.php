<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1>Settings - Footer</h1>
</div>

<form action="<?php echo e(route('admin_setting_footer_update')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row g-4">
        <div class="col-12 col-xl-12">

            <h6 class="cus-heading">Social Links</h6>
            <div class="card-custom-p mb-4">
                <div class="mb-3">
                    <label class="label-custom">Facebook URL</label>
                    <input type="text" name="footer_facebook" value="<?php echo e($setting->footer_facebook); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Twitter URL</label>
                    <input type="text" name="footer_twitter" value="<?php echo e($setting->footer_twitter); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">LinkedIn URL</label>
                    <input type="text" name="footer_linkedin" value="<?php echo e($setting->footer_linkedin); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Instagram URL</label>
                    <input type="text" name="footer_instagram" value="<?php echo e($setting->footer_instagram); ?>" class="form-control-custom">
                </div>
            </div>

            <h6 class="cus-heading">Contact Information</h6>
            <div class="card-custom-p mb-4">
                <div class="mb-3">
                    <label class="label-custom">Phone</label>
                    <input type="text" name="footer_phone" value="<?php echo e($setting->footer_phone); ?>" class="form-control-custom">
                </div>
                <div class="mb-3">
                    <label class="label-custom">Email</label>
                    <input type="text" name="footer_email" value="<?php echo e($setting->footer_email); ?>" class="form-control-custom">
                </div>
            </div>

            <h6 class="cus-heading">Copyright</h6>
            <div class="card-custom-p mb-4">
                <div class="mb-3">
                    <label class="label-custom">Copyright Text</label>
                    <input type="text" name="footer_copyright" value="<?php echo e($setting->footer_copyright); ?>" class="form-control-custom">
                </div>
            </div>

            <div class="card-custom-p mb-4">
                <div>
                    <button type="submit" class="btn-admin-primary">Update</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/project_construction/construction_laravel/resources/views/admin/setting/footer.blade.php ENDPATH**/ ?>