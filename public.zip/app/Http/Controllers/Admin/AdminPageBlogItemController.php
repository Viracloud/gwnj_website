<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PageBlogItem;

class AdminPageBlogItemController extends Controller
{
    public function index()
    {
        $page_data = PageBlogItem::where('id',1)->first();
        return view('admin.page_item.blog',compact('page_data'));
    }

    public function update(Request $request)
    {
        $obj = PageBlogItem::where('id', 1)->first();

        $obj->page_title = $request->page_title;
        $obj->seo_title = $request->seo_title;
        $obj->seo_meta_description = $request->seo_meta_description;

        $obj->save();

        return redirect()->back()->with('success', 'Item updated successfully.');
    }
}
