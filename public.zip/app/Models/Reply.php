<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Reply extends Model
{
    public function comment()
    {
        return $this->belongsTo(Comment::class);
    }
    public function post()
    {
        return $this->belongsTo(Post::class);
    }
}
