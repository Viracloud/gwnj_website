<!DOCTYPE html>
<html class="no-js" lang="en" @if($global_setting->layout_direction == 'rtl') dir="rtl" @endif>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    @if(Request::is('/'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('about'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('services') || Request::is('service/*'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('projects') || Request::is('project/*'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('events') || Request::is('event/*'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('blog') || Request::is('post/*'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('team-members') || Request::is('team-member/*'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('gallery'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('faq'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('login') || Request::is('register') || Request::is('forget-password') || Request::is('reset-password/*'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('dashboard') || Request::is('profile') || Request::is('orders') || Request::is('invoice/*') || Request::is('reviews') || Request::is('wishlist'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('terms-of-use'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('privacy-policy'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif
    
    @if(Request::is('contact'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('shop') || Request::is('product/*'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('cart') || Request::is('checkout'))
        <title>{{ $page_data->seo_title }}</title>
        <meta name="description" content="{{ $page_data->seo_meta_description }}">
    @endif

    @if(Request::is('page/*'))
        @php
            $slug = request()->segment(2);
            $custom_page = App\Models\CustomPage::where('slug', $slug)->first();
        @endphp
        <title>{{ $custom_page->seo_title }}</title>
        <meta name="description" content="{{ $custom_page->seo_meta_description }}">
    @endif

    <link rel="icon" type="image/png" href="{{ asset('uploads/'.$global_setting->favicon) }}">

    <link href="https://fonts.googleapis.com/css2?family=Exo:wght@400;700&family=Rubik:wght@400;700&display=swap" rel="stylesheet">

    @include('front.layouts.styles')

    @if($global_setting->layout_direction == 'rtl')
    <link rel="stylesheet" href="{{ asset('dist-front/css/rtl.css') }}">
    @endif

    <style>
        :root {
            --primary-color: {{ $global_setting->theme_color }};
        }
        .text-primary-orange {
            color: {{ $global_setting->theme_color }} !important;
        }
        .about-img-wrapper::before,
        .about-img-wrapper::after,
        .tmp-team-details-area .social-wrapper a:hover,
        .product-tab-btn.active,
        .reply-link,
        .post-comment-btn {
            background-color: {{ $global_setting->theme_color }} !important;
        }
        .product-tab-btn:hover,
        .tmp-breadcrumb-area a:hover,
        .category-link:hover {
            color: {{ $global_setting->theme_color }} !important;
        }
        .reply-input:focus,
        .product-thumb:hover {
            border-color: {{ $global_setting->theme_color }} !important;
        }
    </style>

</head>
<body>
    <header>
        @include('front.layouts.top')
        @include('front.layouts.nav')
        @include('front.layouts.mobile-nav')

        @yield('banner')
    </header>
    <main>
        @yield('content')
    </main>
    @include('front.layouts.footer')
    @include('front.layouts.scripts')
    @stack('scripts')

</body>
</html>