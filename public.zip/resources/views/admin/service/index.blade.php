@extends('admin.layouts.master')
@section('content')
<div class="d-flex align-items-center justify-content-between mb-4">
    <div class="page-heading mb-0">
        <h1>Services</h1>
    </div>
    <a href="" class="btn-admin-primary" data-bs-toggle="modal" data-bs-target="#modal_add">
        <i class="fa-solid fa-plus me-1"></i>Add Item
    </a>
</div>

<!-- Add Modal -->
<div class="modal fade" id="modal_add" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content modal-content-custom">
            <div class="modal-header modal-header-custom">
                <h5 class="modal-title fw-semibold">Add Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body modal-body-custom">
                <form action="{{ route('admin_service_store') }}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="mb-3">
                        <label class="label-custom">Select Icon *</label>
                        <input type="file" class="form-control-custom" name="icon">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Select Image *</label>
                        <input type="file" class="form-control-custom" name="image">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Title *</label>
                        <input type="text" class="form-control-custom" name="title">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Slug *</label>
                        <input type="text" class="form-control-custom" name="slug">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Short Description *</label>
                        <textarea class="form-control-custom" name="short_description" rows="4"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Description *</label>
                        <textarea id="editor1" class="form-control-custom" name="description" rows="4"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Show on Home?</label>
                        <select class="form-control-custom" name="show_on_home">
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Phone Text</label>
                        <input type="text" class="form-control-custom" name="phone_text">
                    </div>
                    <div class="mb-3">
                        <label class="label-custom">Phone Number</label>
                        <input type="text" class="form-control-custom" name="phone_number">
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn-admin-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- // Add Modal -->


<div class="card-custom-p5">
    <table id="dataTable" class="table-dt stripe hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Icon</th>
                <th>Image</th>
                <th>Title</th>
                <th>Show on Home?</th>
                <th>FAQs</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($services as $service)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>
                    <img src="{{ asset('uploads/'.$service->icon) }}" alt="" class="w_80">
                </td>
                <td>
                    <img src="{{ asset('uploads/'.$service->image) }}" alt="" class="w_200">
                </td>
                <td>{{ $service->title }}</td>
                <td>
                    @if($service->show_on_home == 'Yes')
                    <span class="badge bg-success">Yes</span>
                    @else
                    <span class="badge bg-danger">No</span>
                    @endif
                </td>
                <td>
                    <a href="{{ route('admin_service_faqs', $service->id) }}" class="btn btn-warning btn-sm">Manage FAQs</a>
                </td>
                <td>
                    <div class="d-flex align-items-center gap-1">
                        <a class="btn-icon btn-icon-edit btn-edit-row" data-bs-toggle="modal" data-bs-target="#modal_edit_{{ $loop->iteration }}"><i class="fa-solid fa-pen-to-square text-xs"></i></a>
                        <a class="btn-icon btn-icon-delete" data-bs-toggle="modal" data-bs-target="#modal_delete_{{ $loop->iteration }}"><i class="fa-solid fa-trash text-xs"></i></a>
                    </div>
                </td>
            </tr>
            <!-- Edit Modal -->
            <div class="modal fade" id="modal_edit_{{ $loop->iteration }}" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content modal-content-custom">
                        <div class="modal-header modal-header-custom">
                            <h5 class="modal-title fw-semibold">Edit Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body modal-body-custom">
                            <form action="{{ route('admin_service_update', $service->id) }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3">
                                    <label class="label-custom">Existing Icon</label>
                                    <div>
                                        <img src="{{ asset('uploads/'.$service->icon) }}" alt="" class="w_150">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Change Icon</label>
                                    <input type="file" class="form-control-custom" name="icon">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Existing Image</label>
                                    <div>
                                        <img src="{{ asset('uploads/'.$service->image) }}" alt="" class="w_150">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Change Image</label>
                                    <input type="file" class="form-control-custom" name="image">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Title *</label>
                                    <input type="text" class="form-control-custom" name="title" value="{{ $service->title }}">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Slug *</label>
                                    <input type="text" class="form-control-custom" name="slug" value="{{ $service->slug }}">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Short Description *</label>
                                    <textarea class="form-control-custom" name="short_description" rows="4">{{ $service->short_description }}</textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Description *</label>
                                    <textarea id="editor2" class="form-control-custom" name="description" rows="4">{{ $service->description }}</textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Show on Home?</label>
                                    <select class="form-control-custom" name="show_on_home">
                                        <option value="Yes" {{ $service->show_on_home == 'Yes' ? 'selected' : '' }}>Yes</option>
                                        <option value="No" {{ $service->show_on_home == 'No' ? 'selected' : '' }}>No</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Phone Text</label>
                                    <input type="text" class="form-control-custom" name="phone_text" value="{{ $service->phone_text }}">
                                </div>
                                <div class="mb-3">
                                    <label class="label-custom">Phone Number</label>
                                    <input type="text" class="form-control-custom" name="phone_number" value="{{ $service->phone_number }}">
                                </div>
                                <div class="mb-3">
                                    <button type="submit" class="btn-admin-primary">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- // Edit Modal -->

            <!-- Delete Modal -->
            <div class="modal fade" id="modal_delete_{{ $loop->iteration }}" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content modal-content-custom">
                        <div class="modal-header modal-header-custom">
                            <h5 class="modal-title fw-semibold">Delete Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body modal-body-custom">
                            <form action="{{ route('admin_service_delete', $service->id) }}" method="post">
                                @csrf
                                <div class="mb-3">
                                    <p>
                                        Are you sure you want to delete this item?
                                    </p>
                                </div>
                                <div class="mb-3">
                                    <button type="submit" class="btn-admin-delete">Delete</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- // Delete Modal -->
            @endforeach
        </tbody>
    </table>
</div>
@endsection